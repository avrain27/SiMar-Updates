<?php get_header(); ?>

<main role='main'>

    <article id='content' class='container-fluid'>
        <div class='container'>
            <div class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
                <?php while (have_posts()) : the_post(); ?>
                    <section id='text-content'>
                        <?php the_content(); ?>
                    </section>

                <?php endwhile; ?>
            </div>
            <?php get_sidebar(); ?>
        </div>
    </article>

</main>

<?php get_footer(); ?>