
<?php get_header(); ?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
					<div class='alert alert-danger' style='text-align: left; padding: 1em;'>
						<h3>404: Page Not Found</h3>
						Try a different search, or use the navigation above.
					</div>
			</section>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>