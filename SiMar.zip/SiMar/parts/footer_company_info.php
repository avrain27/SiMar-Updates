<?php function get_footer_company_info() {
	if(get_theme_mod("footer_info"))
	{
		echo do_shortcode(get_theme_mod("footer_info"));
	}
	else if(apply_filters("tsmg_crm_client", "business name"))
	{
		echo '<div id="footer-company-info" class="vcard">';
		echo '	<div class="org" style="display: inline-block">'. apply_filters("tsmg_crm_client", "business name") .'</div> | ';
		echo '	<div class="adr" style="display: inline-block">';
		echo '	<div class="street-address" style="display: inline-block">'. apply_filters("tsmg_crm_client", "street address") .'</div>,';
		echo '		<span class="locality">'. apply_filters("tsmg_crm_client", "city") .'</span>, ';
		echo '		<span class="region">'. apply_filters("tsmg_crm_client", "state") .'</span> ';
		echo '		<span class="postal-code">'. apply_filters("tsmg_crm_client", "zip") .'</span>';
		echo '		</div> | ';
		echo '	<div class="tel" style="display: inline-block"><a href="tel:'. apply_filters("tsmg_crm_client", "phone number") .'">'. apply_filters("tsmg_crm_client", "phone number") .'</a></div>';
		echo '</div>';
	}
}
?>