<?php
function get_client_logo(){
	if(get_theme_mod('header_logo')):
		echo '<a href="'. esc_url( home_url( "/" ) ) .'">';
		echo '<img src="'. get_theme_mod('header_logo') .'" class="img-responsive dark-gray" alt="company logo"/>';
		echo '</a>';
	else:
		echo "<div class='alert alert-danger h4' style='text-align: left; padding: 1em;'>Please add a client logo in the Customizer > Header > Client Logo</div>";
	endif; 
}

function get_client_slogan(){
	if(get_theme_mod('header_slogan'))
		echo get_theme_mod('header_slogan');
	else
		echo apply_filters("tsmg_crm_client", "company slogan");
}

function get_client_header_info(){
	?>
		<div id='phone_info' class='info_content <?php echo (get_theme_mod("phone_toggle")) ? "toggle" : ""; ?>'>
			<div class="glyphicon <?php echo get_theme_mod('header_telephone_glyphicon', 'glyphicon-phone'); ?>"></div> <!-- phone -->
			<div> 
				<div><a href="tel:<?php echo get_client_telephone() ?>"><?php echo get_client_telephone() ?></a></div>
				<?php if(get_client_fax()) echo 'Fax: <a href="tel:'. get_client_fax() .'">'. get_client_fax() .'</a>'; ?> 
			</div>
		</div> 
		<?php if(get_theme_mod('header_hours') || apply_filters("tsmg_crm_client", "business hours")) {  #check for hours since they dont always exist ?>
		<div id='hours_info' class='info_content <?php echo (get_theme_mod("hours_toggle")) ? "toggle" : ""; ?>'>
			<div class="glyphicon <?php echo get_theme_mod('header_hours_glyphicon', 'glyphicon-calendar'); ?>"></div><!-- hours -->
			<div><?php echo get_client_hours(); ?></div>
		</div> 
		<?php } #end hours check ?>
		<div id='email_info' class='info_content <?php echo (get_theme_mod("email_toggle")) ? "toggle" : ""; ?>'>
			<div class="glyphicon <?php echo get_theme_mod('header_email_glyphicon' ,'glyphicon-send'); ?>"></div><!-- email -->
			<div> 
				<?php 
					foreach( get_client_email() as $e ){
						echo '<div><a href="mailto:'. $e .'">'. $e .'</a></div>'; 
					}
				?>
			</div>
		</div> 
	<?php 
}

function get_client_telephone()
{
	return (get_theme_mod('header_telephone')) ? get_theme_mod('header_telephone') : apply_filters("tsmg_crm_client", "phone number");
}

function get_client_fax()
{
	return apply_filters("tsmg_crm_client", "fax number");
}

function get_client_hours()
{
	return (get_theme_mod('header_hours')) ? get_theme_mod('header_hours') : apply_filters("tsmg_crm_client", "business hours");
}

function get_client_email()
{
	$email = (get_theme_mod('header_email')) ? get_theme_mod('header_email') : apply_filters("tsmg_crm_client", "contact email");
	return explode(",", str_replace(", ", ",", $email));
}

?>