<?php
function process_community_list(){
	// break communities into array (they should be comma spaced)
	// get data. if the theme mod is set, pull it from there, else get it from the CRM
	if( get_theme_mod('community_list') )
		$data = get_theme_mod('community_list');
	else
		$data = apply_filters("tsmg_crm_client", "communities");
	$simar_community_data = explode(",", str_replace(", ", ",", $data));
	// sort the community data
	sort($simar_community_data);
	// create array of arrays -- one for each list column
	$simar_community_list = array( array(), array(), array(), array(), array(), array() );
	// put communities into the list.
	for ($i = 0; $i < count($simar_community_data); $i++)
	{
		array_push($simar_community_list[$i%6], $simar_community_data[$i]);
	}
	return $simar_community_list;
}
function get_community_list(){
	$simar_community_list = process_community_list();
	for($i = 0; $i < 6; $i++)
	{
		echo "<div class='col-xs-4 col-sm-2 text-xs-center text-sm-left' style='margin-top: 1em'>";
		for($j = 0; $j < count($simar_community_list[$i]); $j++)
		{
			echo $simar_community_list[$i][$j] . "<br>";
		}
		echo "</div>";

		if($i == 2):
  			echo '<div class="clearfix visible-xs-block"></div>';
  		endif;
	}
}
?>