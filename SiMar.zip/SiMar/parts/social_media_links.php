<?php
function get_social_media_links(){
	//google plus
	$gplus = (get_theme_mod('social_media_google')) ? get_theme_mod('social_media_google') : apply_filters("tsmg_crm_client", "google url"); 
	if($gplus):
	?>
		<a  style='border: 0; ' href="<?php echo $gplus ?>"
		   rel="publisher" target="_blank" style="text-decoration:none;">
		<img src="//ssl.gstatic.com/images/icons/gplus-32.png" alt="Google+" style="border:0;width:32px;height:32px;"/>
		</a>
	<?php
	endif;

	//facebook
	$fb = (get_theme_mod('social_media_facebook')) ? get_theme_mod('social_media_facebook') : apply_filters("tsmg_crm_client", "facebook url"); 
	if($fb):
	?>
		<a target='_blank' href="<?php echo $fb ?>">
		<img src="<?php echo get_template_directory_uri().'/img/facebook-logo.png'; ?>" alt='Facebook'/></a>

	<?php
	endif;

	//facebook 2
	$fb2 = (get_theme_mod('social_media_facebook2'));
	if($fb2):
	?>
		<a target='_blank' href="<?php echo $fb2 ?>">
		<img src="<?php echo get_template_directory_uri().'/img/facebook-logo.png'; ?>" alt='Facebook 2'/></a>

	<?php
	endif;

	// twitter
	$twitter = (get_theme_mod('social_media_twitter')) ? get_theme_mod('social_media_twitter') : apply_filters("tsmg_crm_client", "twitter url"); 
	if($twitter):
	?>
		<a target='_blank' href="<?php echo $twitter ?>">
		<img src="<?php echo get_template_directory_uri().'/img/twitter-logo.png'; ?>" alt='Twitter'/></a>

	<?php
	endif;

	//instagram
	$instagram = (get_theme_mod('social_media_instagram')) ? get_theme_mod('social_media_instagram') : '' ; 
	if($instagram):
	?>
		<a target='_blank' href="<?php echo $instagram ?>">
		<img src="<?php echo get_template_directory_uri().'/img/instagram-logo.png'; ?>" alt='Instagram'/></a>

	<?php
	endif;
}
?>