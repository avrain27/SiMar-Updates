<?php
/**
 * Template Name: Contact Page
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>
 <?php
 	$simar_addr = explode(",", apply_filters("tsmg_crm_client", "city state zip"));
	$simar_addr[1] = explode(" ", trim($simar_addr[1]));
?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<div class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>

				<!-- Contact Form -->
				<?php 
					$contact_shortcode = str_replace('&quot;', '"', get_post_meta( get_the_ID(), 'simar-contact-shortcode', true ));
					echo do_shortcode('[simar_contact_header]');
					echo do_shortcode('[simar_contact]'.$contact_shortcode.'[/simar_contact]');
				?>

				<div class='row' id='contact-media'>
 					<div class='col-xs-12 col-xs-offset-0 col-md-6 text-xs-justify col-md-offset-0' style='margin-top: 1em'>
						<img src='<?php the_post_thumbnail_url() ?>' class='img-responsive thumbnail center-block' alt='contact-image'>
					</div>

 					<div class='col-xs-12 col-xs-offset-0 col-md-6 text-xs-justify col-md-offset-0' style='margin-top: 1em'>
						<?php echo do_shortcode('[simar_map ratio="4by3"]'); ?>
					</div>
				</div>
			</div>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>