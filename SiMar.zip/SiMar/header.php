<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo apply_filters("tsmg_crm_seo", "meta description"); ?>">
	<meta name="keywords" content="<?php echo apply_filters("tsmg_crm_seo", "meta keywords"); ?>">
	<meta name="title" content="<?php echo apply_filters("tsmg_crm_seo", "meta title"); ?>">
	<link rel="icon" type="image/png" href="<?php if(get_theme_mod('client_favicon')): echo get_theme_mod('client_favicon'); endif; ?>" />
	
	<title><?php echo (apply_filters("tsmg_crm_seo", "meta title")) ? apply_filters("tsmg_crm_seo", "meta title") : get_the_title();
																 echo " | " . apply_filters("tsmg_crm_client", "business name") ?></title>

	<title></title>

	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<?php wp_head() ?>
</head>

<body <?php body_class() ?>>	

<script>//document.getElementsByTagName("BODY")[0].style.visibility = "hidden";</script>

<section id='fixed-scroll'>
<header class='container-fluid'>
<div class='container '>
<div class='row vertical-align-sm text-xs-center'>
	
	<section id='left' class='col-sm-4 col-sm-offset-0 col-xs-10 col-xs-offset-1 text-md-left'>
		<?php dynamic_sidebar("simar_header_left"); ?>
	</section>

	<section id='mid' class='col-sm-4 col-sm-offset-0 col-xs-10 col-xs-offset-1 text-md-center'>
		<?php dynamic_sidebar("simar_header_mid"); ?>
	</section>

	<section id='right' class='col-sm-4 col-sm-offset-0 col-xs-10 col-xs-offset-1 text-sm-right'>
		<?php dynamic_sidebar("simar_header_right"); ?>
	</section>

</div>
</div>
</header>

<nav class="navbar navbar-default container-fluid" role="navigation">
	<div class='container'>
	<div class='row'>
		<div class='col-xs-12'>
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		        </button>
		    <div><a class="navbar-brand" href="#"><?php echo apply_filters("tsmg_crm_client", "business name"); ?></a></div>
		    </div>

		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse navbar-ex1-collapse">
		        <?php
		        wp_nav_menu( array(
		            'theme_location' => 'Main Menu',
		            'depth' => 2,
		            'container' => false,
		            'menu_class' => 'nav navbar-nav',
		            'fallback_cb' => 'wp_page_menu',
		            //Process nav menu using our custom nav walker
		            'walker' => new wp_bootstrap_navwalker())
		        );
		        ?>
		    </div><!-- /.navbar-collapse --> 
    	</div>
    </div>
    </div> <!-- container -->
</nav>
</section> <!-- fixed scroll -->

<div id='fixed-scroll-padder'></div>

<section id='gallery' class='container-fluid'>
	<?php dynamic_sidebar("simar_gallery"); # full width gallery enabled ?>
	<div class='container'>
	<div class='row'>
	<div class='col-xs-12'>
		<h1><?php echo apply_filters("tsmg_crm_seo", "h1 header tag"); ?></h1>
	</div>
	</div>
	</div>
</section>