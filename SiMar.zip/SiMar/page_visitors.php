<?php
/**
 * Template Name: Visitors Page
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.2.0
 */
 ?>

 <?php get_header(); ?>
 <?php
 	$simar_addr = explode(",", apply_filters("tsmg_crm_client", "city state zip"));
	$simar_addr[1] = explode(" ", trim($simar_addr[1]));
?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<div class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>

				<ul class="list-group">
				  <li class="list-group-item list-group-item-info">VISITORS</li>
				  <li class="list-group-item">Today's visitors: <?php echo do_shortcode("[slimstat f='count' w='ip']strtotime equals today[/slimstat]"); ?></li>
				  <li class="list-group-item">Visitors this Month: <?php echo do_shortcode("[slimstat f='count' w='ip'][/slimstat]"); ?></li>
				  <li class="list-group-item">Unique Total Visitors: <?php echo do_shortcode("[slimstat f='count-all' w='ip'][/slimstat]"); ?></li>
				</ul>
			</div>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>