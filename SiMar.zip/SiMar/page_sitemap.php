<?php
/**
 * Template Name: Site Map
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>
				<div class="list-group">
				<a class="list-group-item active">Site Map</a>
				<?php
				/* Page Info -- MASS INPUT */
				$pages = get_all_page_ids(); # gets all PAGE ids (excludes index)
				$id = get_the_ID(); # Gets page ID
				for($i=0; $i<count($pages); $i++){
					echo "<a href='?p=".$pages[$i]."' class='list-group-item'>".get_the_title($pages[$i])."</a>";
				}
				?>
				</div>
			</section>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>