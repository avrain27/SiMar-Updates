<?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>

	<main role='main'>

		<article id='content' class='container-fluid'>
			<div class='container'>
			<div class='row text-xs-center'>
				<section class='col-xs-12 text-xs-justify'>
					<?php the_content(); ?>
				</section>
			</div>
			</div>
		</article>		

		<section id='video' class='container-fluid'>
			<div class='container'>
			<div class='row text-xs-center'>
				<section class='col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2'>
					<?php get_youtube_embed(); ?>
				</section>
			</div>
			</div>
		</section>
		
		<?php
		# PAGE EXCERPTS
			$args = array( 'post_type' => 'simar_page_excerpts', 'posts_per_page' => '6');
			$loop = new WP_Query( $args );
			$count = $loop->post_count;
			switch($count) {
				case(1):
					$flex_class = 'col-md-12';
					break;
				case(2):
					$flex_class = 'col-md-6';
					break;
				default: // 3
					$flex_class = 'col-md-4';
					break;
			}
		?>
		<?php if ($loop->have_posts()) : #check for any page-excerpts ?>
		<section id='page-excerpts' class='container-fluid'>
			<div class='container'>
			<div class='row'>
					<?php
						while ( $loop->have_posts() ) : $loop->the_post(); ?>
						  <div class="<?php echo $flex_class; ?> col-md-offset-0 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 page-excerpt">
						  	<h3 class="well"><?php echo the_title(); ?></h3>
						  	<?php the_content(); ?>
						 	<!-- <a href="<?php #echo the_permalink() ?>" class="btn btn-default btn-sm btn-block">Read More!</a> -->
						  </div>
						<?php endwhile;
					?>
			</div>
		</section>
		<?php endif; #end page-excerpts ?>

		<article id='features' class='container-fluid text-xs-center'>
			<div class='container'>
			<div class='row'>
				<section id='announcements' class='col-xs-8 col-xs-offset-2 col-md-5 col-md-offset-0'>
					<h3>announcements</h3>
				</section>
				<section id='testimonials' class='col-xs-8 col-xs-offset-2 col-md-5 col-md-offset-2'>
					<h3>testimonials</h3>
				</section>
			</div>
			</div>
		</article>

		<section id='scrolling-gallery' class='container-fluid'>
			<div class='container'>
			<div class='row'>
				<div class='col-xs-12 text-center'>
					<?php 
					if(get_theme_mod("scrolling_gallery")):
						echo do_shortcode( get_theme_mod('scrolling_gallery', '') ); 
					else:
						echo "<div class='alert alert-warning h4' style='text-align: left; padding: 1em;'>Input gallery Shortcode in Theme Customizer > Home Page > Scrolling Gallery</div>";
					endif;
					?>
				</div>
			</div>
			</div>
		</section>

	</main>

<?php endwhile; ?>

<?php get_footer();?>

