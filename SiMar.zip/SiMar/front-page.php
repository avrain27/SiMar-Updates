<?php get_header(); ?>

<main role='main'>
	<section id='text-content'>
		<?php while( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; ?>
	</section>
</main>

<?php get_footer(); ?>