<?php
/**
 * Template Name: No-Sidebar
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.2
 */
 ?>

<?php get_header(); ?>

<main role='main'>

	<article id='content' class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-12 col-xs-offset-0 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>
			</section>
		</div>
	</article>

</main>

<?php get_footer(); ?>