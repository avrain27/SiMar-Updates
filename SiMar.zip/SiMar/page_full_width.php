<?php
/**
 * Template Name: Full Width
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.2
 */
 ?>

<?php get_header(); ?>

<main role='main'>
	<section id='text-content'>
		<?php while( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; ?>
	</section>
</main>

<?php get_footer(); ?>