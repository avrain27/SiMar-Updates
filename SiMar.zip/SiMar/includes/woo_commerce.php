<?php
	// remove standard hooks
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

	// add hooks
	add_action('woocommerce_before_main_content', 'my_theme_wrapper_start', 10);
	add_action('woocommerce_after_main_content', 'my_theme_wrapper_end', 10);

	function my_theme_wrapper_start() {
		?>
			<main role='main'>

			<article id='content' class='container-fluid'>
				<div class='container'>
				<div class='row'>
					<section id='text-content' class='col-xs-12 col-xs-justify'>
		<?php
	}

	function my_theme_wrapper_end() {
		?>
			</section> </div> </div> </article></main>
		<?php
	}

	// declare theme support
	add_action( 'after_setup_theme', 'woocommerce_support' );
		function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}
?>