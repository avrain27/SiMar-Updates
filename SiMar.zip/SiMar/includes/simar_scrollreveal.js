function simar_scrollreveal()
{
	window.sr = ScrollReveal({duration: 750, viewFactor: 0.5, reset: false, scale: 1});
	sr.reveal('div.reveal div.embed-responsive');
	sr.reveal('div.reveal div.simar_post');
	sr.reveal('div.simar_post.reveal', {origin: 'right'});
	sr.reveal('section#communities .container');
	sr.reveal('div#social-links', {origin: 'right'});
	sr.reveal('div.reveal');
}
simar_scrollreveal();