jQuery(document).ready(function($){
	//////////////////////////////////////////////////////////////////
	// PADDING FIXES
	// on load
	var cssListener = setInterval(function(){if($(".navbar-nav>li").css("float") == "left"){
		clearInterval(cssListener);
		$( "<style>@media (min-width: 768px){ section#gallery.offset {padding-top : "+ ($('section#fixed-scroll').height() + 16) +"px} }</style>" ).appendTo( "footer" );
		$('section#gallery').addClass("offset");
	}},50);
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	// LISTENERS
	var limit = $('section#fixed-scroll').height();
	$(window).bind('scroll', function(){ //check on scroll
		$('section#fixed-scroll').toggleClass('fixed', $(window).scrollTop() > limit);
	});
	if($(window).scrollTop > limit){ // check on load
		$('section#fixed-scroll').toggleClass('fixed');
	}
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	// BOOTSTRAP JQUERY HOVER
	if ( $('li.dropdown').length > 0)
	{
		$('li.dropdown, li.dropdown-submenu').on('mouseenter', function() {
			if($(document).width() >= 768)
			{
				$(this).addClass('open'); // TOGGLE open
				$childMenu = $(this).find('ul.dropdown-menu'); // LEFT FIX menus that are out of bounds
				if($childMenu.offset().left + $childMenu.width() > $(document).width() ) // if menu wont be fully displayed on page, hook left
				{
					$childMenu.addClass('left-fix');
					$childMenu.css('left', $this.width() + "px");
				}
			}
		});
		$('li.dropdown, li.dropdown-submenu').on('mouseleave', function() {
			if($(document).width() >= 768)
			{
				$(this).removeClass('open');
				$childMenu = $(this).find('ul.dropdown-menu'); // REMOVE Left Fix
					$childMenu.removeClass('left-fix');
			}
		});
		$('li.dropdown, li.dropdown-submenu').on('mouseenter')
		{
			$childMenu = $(this).find('ul.dropdown-menu');
			if($childMenu.offset().left + $childMenu.width() > $(document).width() ) // if menu wont be fully displayed on page, hook left
				$childMenu.addClass('left-fix');
		}
	}
});