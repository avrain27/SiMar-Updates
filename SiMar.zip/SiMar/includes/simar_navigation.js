jQuery(document).ready(function($){
	//////////////////////////////////////////////////////////////////
	// PADDING FIXES
	// on lode
	$( "<style>@media (min-width: 768px){ section#gallery.offset {padding-top : "+ ($('section#fixed-scroll').height() + 16) +"px} }</style>" ).appendTo( "footer" );
	$('section#gallery').addClass("offset");
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	// LISTENERS
	var limit = $('section#fixed-scroll').height();
	$(window).bind('scroll', function(){ //check on scroll
		$('section#fixed-scroll').toggleClass('fixed', $(window).scrollTop() > limit);
	});
	if($(window).scrollTop > limit){ // check on load
		$('section#fixed-scroll').toggleClass('fixed');
	}
	//////////////////////////////////////////////////////////////////

});