jQuery(document).ready(function($){
	//////////////////////////////////////////////////////////////////
	// PADDING FIXES
	// on load
	var cssListener = setInterval(function(){if($(".navbar-nav>li").css("float") == "left"){
		clearInterval(cssListener);
		$( "<style>@media (min-width: 768px){ section#gallery.offset {padding-top : "+ ($('section#fixed-scroll').height() + 16) +"px} }</style>" ).appendTo( "footer" );
		$('section#gallery').addClass("offset");
	}},50);
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	// LISTENERS
	var limit = $('section#fixed-scroll').height();
	$(window).bind('scroll', function(){ //check on scroll
		$('section#fixed-scroll').toggleClass('fixed', $(window).scrollTop() > limit);
	});
	if($(window).scrollTop > limit){ // check on load
		$('section#fixed-scroll').toggleClass('fixed');
	}
	//////////////////////////////////////////////////////////////////

	//////////////////////////////////////////////////////////////////
	// BOOTSTRAP JQUERY HOVER
/*	$('li.dropdown').on('mouseenter mouseleave click tap', function() {
	  $(this).toggleClass("open");
	});*/
});