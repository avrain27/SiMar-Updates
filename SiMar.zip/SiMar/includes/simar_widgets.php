<?php
/**
 * Register our sidebars and widgetized areas.
 *
 */

// Video Widget
class simar_Video_Widget extends WP_Widget {
  /**
  * To create the example widget all four methods will be 
  * nested inside this single instance of the WP_Widget class.
  **/
  public function __construct() {
    $widget_options = array( 
      'classname' => 'simar_client_video',
      'description' => "This pulls the client's video from the CRM.",
    );
    parent::__construct( 'simar_client_video', 'Simar Client Video', $widget_options );
  }

  public function widget( $args, $instance ) {
    $tags = $instance['divi'] ? 'divi="true" ': '';
    echo do_shortcode('[simar_video '.$tags.']');
  }

  public function form( $instance ) {
    ?>
      <br /><br />
      <input class="checkbox" type="checkbox" <?php checked( $instance[ 'divi' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'divi' ); ?>" name="<?php echo $this->get_field_name( 'divi' ); ?>" /> 
      <label for="<?php echo $this->get_field_id( 'divi' ); ?>">Using Divi Builder</label>
      <br /><br />
    <?php
  }
  
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance[ 'divi' ] = $new_instance[ 'divi' ];
    return $instance;
  }

}

// Map Widget
class simar_Map_Widget extends WP_Widget {
  /**
  * To create the example widget all four methods will be 
  * nested inside this single instance of the WP_Widget class.
  **/
  public function __construct() {
    $widget_options = array( 
      'classname' => 'simar_client_map',
      'description' => "This pulls a Google Map of the client's address from the CRM.",
    );
    parent::__construct( 'simar_client_map', 'Simar Client Map', $widget_options );
  }

  public function widget( $args, $instance ) {
    $tags = $instance['ratio'] ? 'ratio='.$instance['ratio'].' ' : '';
    echo do_shortcode('[simar_map '.$tags.']');
  }

  public function form( $instance ) {
    ?>
      <br /><br />
      <label for="<?php echo $this->get_field_id( 'ratio' ); ?>">Aspect Ratio</label>
      <br /><br />
      <input class="radio" type="radio" value='16by9' <?php checked( $instance[ 'ratio' ], '16by9' ); ?> name="<?php echo $this->get_field_name( 'ratio' ); ?>" />16:9
      <br /><br />
      <input class="radio" type="radio" value='4by3'  <?php checked( $instance[ 'ratio' ], '4by3' ); ?> name="<?php echo $this->get_field_name( 'ratio' ); ?>" />4:3
      <br /><br />
    <?php
  }
  
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance[ 'ratio' ] = $new_instance[ 'ratio' ];
    return $instance;
  }

}

// Image Widget
class simar_Gallery_Image_Widget extends WP_Widget {
  /**
  * To create the example widget all four methods will be 
  * nested inside this single instance of the WP_Widget class.
  **/
  public function __construct() {
    $widget_options = array( 
      'classname' => 'simar_gallery_image',
      'description' => "This pulls the gallery image defined in the customizer.",
    );
    parent::__construct( 'simar_gallery_image', 'Simar Gallery Image', $widget_options );
  }

  public function widget( $args, $instance ) {
	echo $args['before_widget']; 
  $ft = $instance['featured'] ? 'true' : 'false';
  $full = $instance['fullwidth'] ? true : false;
    if(!get_theme_mod("gallery_home_image") && $ft == "false")
    {
      echo "<div class='col-xs-6 col-xs-offset-3'><div class='alert alert-danger h4' style='text-align: left; padding: 1em;'>Please add a header image in the Customizer > Gallery > Gallery Home Page Image</div></div>";
    }
    else if( !has_post_thumbnail() && $ft == "true")
    {
      echo "<div class='col-xs-6 col-xs-offset-3'><div class='alert alert-danger h4' style='text-align: left; padding: 1em;'>Please add a featured image to this post.</div></div>";
    }
    else 
    {
      if($full) # full width gallery enabled
      {
          echo "<div class='row'><div class='col-xs-12'>";
          echo do_shortcode('[simar_gallery_image featured="'.$ft.'"]');
          echo "</div></div>";
      }
      else # full width gallery enabled
      {
          echo "<div class='container'><div class='row'><div class='col-xs-12'>";
          echo do_shortcode('[simar_gallery_image featured="'.$ft.'"]');
          echo "</div></div></div>";
      }
    }
	echo $args['after_widget'];
  }

  public function form( $instance ) {
    ?>
      <p>
      <?php if($instance['desc']) echo "<h2>".$instance['desc']."</h2><br />"; ?>
      <input class="checkbox" type="checkbox" <?php checked( $instance[ 'fullwidth' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'fullwidth' ); ?>" name="<?php echo $this->get_field_name( 'fullwidth' ); ?>" /> 
      <label for="<?php echo $this->get_field_id( 'full' ); ?>">Full Width Image (Uncheck ONLY if in header!)</label>
      <br /><br />
      <input class="checkbox" type="checkbox" <?php checked( $instance[ 'featured' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'featured' ); ?>" name="<?php echo $this->get_field_name( 'featured' ); ?>" /> 
      <label for="<?php echo $this->get_field_id( 'featured' ); ?>">Use Featured Image Instead of Site Image</label>
      <br /><br />
      <label for="<?php echo $this->get_field_id( 'desc' ); ?>">Description:</label><br />
      <textarea style='width: 100%' id="<?php echo $this->get_field_id( 'desc' ); ?>" name="<?php echo $this->get_field_name( 'desc' ); ?>"><?php echo $instance['desc'] ? $instance['desc'] : ''; ?></textarea>
      </p>
    <?php
  }
  
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance[ 'fullwidth' ] = $new_instance[ 'fullwidth' ];
    $instance[ 'featured' ] = $new_instance[ 'featured' ];
    $instance[ 'desc' ] = $new_instance[ 'desc' ];
    return $instance;
  }

}

// Announcement Widget
class simar_Post_Widget extends WP_Widget {
  /**
  * To create the example widget all four methods will be 
  * nested inside this single instance of the WP_Widget class.
  **/
  public function __construct() {
    $widget_options = array( 
      'classname' => 'simar_post_widget',
      'description' => "This pulls a specified post from the Simar Posts section in the dashboard.",
    );
    parent::__construct( 'simar_post_widget', 'Simar Post', $widget_options );
  }

  public function widget( $args, $instance ) {
  $tags = ( $instance['title'] ) ? ' title="'. $instance['title'] .'" ' : '';
  $tags .= ( $instance['reveal'] ) ? 'reveal="true" ' : 'reveal="false"';
  $tags .= ( $instance['divi'] ) ? 'divi="true" ' : '';
	 echo do_shortcode('[simar_post '. $tags .' ]');
  }

  public function form( $instance ) {
  	$title = ! empty( $instance['title'] ) ? $instance['title'] : ''; ?>
 	<p>
    <label for="<?php echo $this->get_field_id( 'title' ); ?>">Post Title:</label>
    <select name="<?php echo $this->get_field_name( 'title' ); ?>">
    	<option value="<?php echo esc_attr( $title );?>"><?php echo (!empty($title)) ? esc_attr( $title ) : 'Select a Post';?></option>
    	<?php 
    		global $post;
	    	$args = array( 'post_type' => 'simar_post', 'posts_per_page' => '-1');
			$myposts = get_posts($args);
			foreach ($myposts as $post):
				setup_postdata( $post ); ?>
				<option value="<?php the_title(); ?>">
					<?php the_title(); ?>
				</option>
				<?php	
			endforeach;
			wp_reset_postdata();
		?>
    </select>
    <br /><br />
    <input class="checkbox" type="checkbox" <?php checked( $instance[ 'reveal' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'reveal' ); ?>" name="<?php echo $this->get_field_name( 'reveal' ); ?>" /> 
    <label for="<?php echo $this->get_field_id( 'reveal' ); ?>">Enable Scroll Reveal</label>
    <br /><br />
    <input class="checkbox" type="checkbox" <?php checked( $instance[ 'divi' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'divi' ); ?>" name="<?php echo $this->get_field_name( 'divi' ); ?>" /> 
    <label for="<?php echo $this->get_field_id( 'divi' ); ?>">Using Divi Builder</label>
  	</p><?php 
  }

  public function update( $new_instance, $old_instance ) {
	  $instance = $old_instance;
    $instance[ 'title' ] = strip_tags( $new_instance[ 'title' ] );
    $instance[ 'reveal' ] = $new_instance[ 'reveal' ];
	  $instance[ 'divi' ] = $new_instance[ 'divi' ];
	  return $instance;
  }
}

// register
function simar_widgets_init() {

  register_sidebar( array(
    'name'          => 'Sidebar',
    'id'            => 'simar_sidebar',
    'before_widget' => '<div>',
    'after_widget'  => '</div>',
    'before_title'  => '<h2 class="rounded">',
    'after_title'   => '</h2>',
  ) );

	register_sidebar( array(
		'name'          => 'Header Image Gallery',
		'id'            => 'simar_gallery',
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '',
		'after_title'   => '',
	) );

  register_widget( 'simar_Video_Widget' );
  register_widget( 'simar_Map_Widget' );
	register_widget( 'simar_Gallery_Image_Widget' );
	register_widget('simar_Post_Widget');
	

}
add_action( 'widgets_init', 'simar_widgets_init' );

?>