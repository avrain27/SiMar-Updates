<?php
/* === Parent: simar_customizer.php === */
/* == Settings and Controls for: Nav == */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('nav_bg_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'nav_bg_color', array(
	'label' 	=> 'Navigation Background Color',
	'section' 	=> 'nav_settings'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('nav_font_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'nav_font_color', array(
	'label' 	=> 'Navigation Font Color',
	'section' 	=> 'nav_settings'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('nav_highlight_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'nav_highlight_color', array(
	'label' 		=> 'Navigation Link Highlight Color',
	'section' 		=> 'nav_settings',
	'description'	=> 'for hovered/active links in the navigation bar.'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('nav_highlight_intensity', array(
	'default' 			=> '25',
	'sanitize_callback' => 'absint'
));
$wp_customize->add_control('nav_highlight_intensity', array(
   'label'      => __( 'Highlight Color Intensity', 'SiMar' ),
   'section'    => 'nav_settings',
   'description' 	=> 'enter an intensity value (0 to 100).'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('nav_border_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'nav_border_color', array(
	'label' 		=> 'Navigation Border Color',
	'section' 		=> 'nav_settings'
)));
/////////////////////////////////////////////////////////
?>