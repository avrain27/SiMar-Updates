<?php
/* ===== Parent: simar_customizer.php ===== */

/* = Settings and Controls for: Home Page - Color Scheme = */
/////////////////////////////////////////////////////////
$wp_customize->add_setting('content_bg_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'content_bg_color', array(
	'label' 		=> 'Content BG Color',
	'section' 		=> 'home_page_color_scheme',
	'description' 	=> __ ('Background for the Content section. This is the content pulled from the Page section in the dashboard')
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('video_bg_color', array(
	'default' 			=> '#eee',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'video_bg_color', array(
	'label' 	=> 'Video Banner BG Color',
	'section' 	=> 'home_page_color_scheme'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('page_excerpts_bg_color', array(
	'default' 			=> '#353560',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'page_excerpts_bg_color', array(
	'label' 	=> 'Page Excerpts BG Color',
	'section' 	=> 'home_page_color_scheme'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('features_bg_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'features_bg_color', array(
	'label' 	=> 'Announcements/Testimonials BG Color',
	'section' 	=> 'home_page_color_scheme'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('scrolling_gallery_bg_color', array(
	'default' 			=> '#eee',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'scrolling_gallery_bg_color', array(
	'label' 	=> 'Scrolling Images BG Color',
	'section' 	=> 'home_page_color_scheme'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('scrolling_gallery', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea'
));	
$wp_customize->add_control('scrolling_gallery', array(
   'label'      => __( 'Scrolling Gallery Tag', 'SiMar' ),
   'description'=> 'Shortcode to be used for the scrolling image slider',
   'section'    => 'home_page_scrolling_gallery'
));
/////////////////////////////////////////////////////////
?>
