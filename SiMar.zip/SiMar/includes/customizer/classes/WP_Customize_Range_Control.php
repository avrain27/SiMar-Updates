<?php
function register_Classes()
{
    class WP_Customize_Range_Control extends WP_Customize_Control
    {
        public $type = 'custom_range';
        public function enqueue()
        {
            wp_enqueue_script(
                'cs-range-control',
                get_template_directory_uri().'/includes/customizer/classes/range-control.js',
                array('jquery'),
                false,
                true
            );
        }
        public function render_content()
        {
            ?>
            <label>
                <?php if ( ! empty( $this->label )) : ?>
                    <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
                <?php endif; ?>
                <div class="cs-value-unit">
                    <span class="cs-range-value"><?php echo esc_attr($this->value()); ?></span>
                    <?php if ( ! empty( $this->description )) : ?>
                        <?php echo ' ' . $this->description; #UNITS ?>
                    <?php endif; ?>
                </div>
                <input data-input-type="range" type="range" <?php $this->input_attrs(); ?> value="<?php echo esc_attr($this->value()); ?>" <?php $this->link(); ?> />
            </label>
            <?php
        }
    }
}
add_action( 'customize_register', 'register_Classes' );
?>
