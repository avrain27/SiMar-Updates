/**
 * This file adds some LIVE to the Theme Customizer live preview. To leverage
 * this, set your custom settings to 'postMessage' and then add your handling
 * here. Your javascript should grab settings from customizer controls, and 
 * then make any necessary changes to the page using jQuery.
 */
( function( $ ) {
    //////////////////////////////////////////////////////////////////////////////////
	//                                 FONT SETTINGS                                //
    //////////////////////////////////////////////////////////////////////////////////
	//disable css text transitions
	$('footer').append("<style>*{  -webkit-transition: font-size 1ms !important;-moz-transition: font-size 1ms !important;-o-transition: font-size 1ms !important;transition: font-size 1ms !important;}</style>"); 
    //////////////////////////////////////////////////////////
    
    //////////////////////////////////////////////////////////
    // header font size
	wp.customize( 'header_font_size', function( value ) {
		value.bind( function( newval ) {
			$('header').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // navigation font size
	wp.customize( 'navigation_font_size', function( value ) {
		value.bind( function( newval ) {
			$('.navbar').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // h1-header font size
	wp.customize( 'h1_font_size', function( value ) {
		value.bind( function( newval ) {
			$('section#gallery h1').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////////////
	//                               HEADER SETTINGS                                //
    //////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // Color Scheme    
    wp.customize( 'header_bg_color', function( value ) {
		value.bind( function( newval ) {
			$('header').css('background', newval);
		} );
	} ); 
    wp.customize( 'header_font_color', function( value ) {
		value.bind( function( newval ) {
			$('header').css('color', newval);
		} );
	} ); 
    wp.customize( 'header_link_color', function( value ) {
		value.bind( function( newval ) {
			$('header a').css('color', newval);
		} );
	} ); 
    wp.customize( 'header_glyphicon_color', function( value ) {
		value.bind( function( newval ) {
			$('header div.glyphicon').css('color', newval);
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // Header-Collapse
	wp.customize( 'misc_toggle', function( value ) {
		value.bind( function( newval ) {
			if(newval == true)
				$('div#misc').addClass('toggle');
			else 
				$('div#misc').removeClass('toggle');
		} );
	} );
	wp.customize( 'phone_toggle', function( value ) {
		value.bind( function( newval ) {
			if(newval == true)
				$('div#phone_info').addClass('toggle');
			else 
				$('div#phone_info').removeClass('toggle');
		} );
	} );
	wp.customize( 'hours_toggle', function( value ) {
		value.bind( function( newval ) {
			if(newval == true)
				$('div#hours_info').addClass('toggle');
			else 
				$('div#hours_info').removeClass('toggle');
		} );
	} );
	wp.customize( 'email_toggle', function( value ) {
		value.bind( function( newval ) {
			if(newval == true)
				$('div#email_info').addClass('toggle');
			else 
				$('div#email_info').removeClass('toggle');
		} );
	} );

    //////////////////////////////////////////////////////////
    // Images
	wp.customize( 'header_logo', function( value ) {
		value.bind( function( newval ) {
			$('section#logo img').attr('src', newval); 
		} );
	} );
	wp.customize( 'logo_size', function( value ) {
		value.bind( function( newval ) {
			$('footer').append("<style>section#logo img{max-height: "+newval+"px;}</style>"); 
		} );
	} );
	wp.customize( 'collapsed_logo_size', function( value ) {
		value.bind( function( newval ) {
			$('footer').append("<style>section#fixed-scroll.fixed section#logo img{max-height: "+newval+"px;}</style>"); 
		} );
	} );
	wp.customize( 'collapsed_logo_size', function( value ) {
		value.bind( function( newval ) {
			$('footer').append("<style>section#fixed-scroll.fixed section#logo img{max-height: "+newval+"px;}</style>"); 
		} );
	} );

    //////////////////////////////////////////////////////////
    // Info
	wp.customize( 'header_slogan', function( value ) {
		value.bind( function( newval ) {
			$('section#misc div').html(newval);
		} );
	} );
	wp.customize( 'header_telephone', function( value ) {
		value.bind( function( newval ) {
			$('div#phone_info div:nth-child(2) div:first-child').html('<a href="tel:'+newval+'">'+newval+'</a>');
		} );
	} );
	wp.customize( 'header_hours', function( value ) {
		value.bind( function( newval ) {
			$('div#hours_info div:nth-child(2)').html(newval);
		} );
	} );
	wp.customize( 'header_email', function( value ) {
		value.bind( function( newval ) {
			newval.trim();
			arr = newval.split(",");
			$("div#email_info div:nth-child(2)").html('');
			for(var i = 0; i < arr.length; ++i)
			{
				$('div#email_info div:nth-child(2)').append('<div><a href="tel:'+arr[i]+'">'+arr[i]+'</a></div>');
			}
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////////////
	//                               GALLERY SETTINGS                               //
    //////////////////////////////////////////////////////////////////////////////////
    wp.customize( 'gallery_bg_color', function( value ) {
		value.bind( function( newval ) {
			$('section#gallery, div#fixed-scroll-padder').css('background', newval);
		} );
	} );
    wp.customize( 'gallery_font_color', function( value ) {
		value.bind( function( newval ) {
			$('section#gallery, div#fixed-scroll-padder').css('color', newval);
		} );
	} );

    //////////////////////////////////////////////////////////////////////////////////
	//                             COMMUNITIES SETTINGS                             //
    //////////////////////////////////////////////////////////////////////////////////	
    wp.customize( 'community_bg_color', function( value ) {
		value.bind( function( newval ) {
			$('section#communities').css('background', newval);
		} );
	} );
    wp.customize( 'community_header_color', function( value ) {
		value.bind( function( newval ) {
			$('section#communities .row:first-child').css('color', newval);
		} );
	} );
    wp.customize( 'community_font_color', function( value ) {
		value.bind( function( newval ) {
			$('section#communities .row:nth-child(2)').css('color', newval);
		} );
	} );

} )( jQuery );