/**
 * This file adds some LIVE to the Theme Customizer live preview. To leverage
 * this, set your custom settings to 'postMessage' and then add your handling
 * here. Your javascript should grab settings from customizer controls, and 
 * then make any necessary changes to the page using jQuery.
 */
( function( $ ) {
    //////////////////////////////////////////////////////////
	//disable css text transitions
	$('footer').append("<style>*{  -webkit-transition: font-size 1ms !important;-moz-transition: font-size 1ms !important;-o-transition: font-size 1ms !important;transition: font-size 1ms !important;}</style>"); 
    //////////////////////////////////////////////////////////
    
    //////////////////////////////////////////////////////////
    // header font size
	wp.customize( 'header_font_size', function( value ) {
		value.bind( function( newval ) {
			$('header').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // navigation font size
	wp.customize( 'navigation_font_size', function( value ) {
		value.bind( function( newval ) {
			$('.navbar').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // h1-header font size
	wp.customize( 'h1_font_size', function( value ) {
		value.bind( function( newval ) {
			$('section#gallery h1').css('font-size', newval+'px');
		} );
	} );
    //////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////
    // collapsed-logo max-height
	wp.customize( 'logo_size', function( value ) {
		value.bind( function( newval ) {
			$('footer').append("<style>section#logo img{max-height: "+newval+"px;}</style>"); 
		} );
	} );
    //////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////
    // collapsed-logo max-height
	wp.customize( 'collapsed_logo_size', function( value ) {
		value.bind( function( newval ) {
			$('footer').append("<style>section#fixed-scroll.fixed section#logo img{max-height: "+newval+"px;}</style>"); 
		} );
	} );
    //////////////////////////////////////////////////////////

} )( jQuery );