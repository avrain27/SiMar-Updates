<?php
/* ==== Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Footer == */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('body_font_family', array(
	'default' 			=> '"Helvetica Neue",Helvetica,Arial,sans-serif',
	'sanitize_callback' => 'esc_textarea'
));	
$wp_customize->add_control('body_font_family', array(
   'label'      => __( 'Body Font' ),
   'description'=> 'Enter comma separated names to be used as CSS. Ex: "Helvetica Neue", Calibri',
   'section'    => 'general_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_font_size', array(
  'default'           => 14,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'header_font_size',
  array(
      'label'       => __('Header Font Size'),
      'section'     => 'general_settings',
      'settings'    => 'header_font_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 8,
          'max' => 32,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('navigation_font_size', array(
  'default'           => 14,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'navigation_font_size',
  array(
      'label'       => __('Navigation Font Size'),
      'section'     => 'general_settings',
      'settings'    => 'navigation_font_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 8,
          'max' => 32,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('h1_font_size', array(
  'default'           => 16,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'h1_font_size',
  array(
      'label'       => __('H1-Header Font Size'),
      'section'     => 'general_settings',
      'settings'    => 'h1_font_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 8,
          'max' => 32,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('logo_size', array(
  'default'           => 150,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'logo_size',
  array(
      'label'       => __('Logo Size'),
      'section'     => 'general_settings',
      'settings'    => 'logo_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 25,
          'max' => 300,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('collapsed_logo_size', array(
  'default'           => 75,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'collapsed_logo_size',
  array(
      'label'       => __('Collapsed Logo Size'),
      'section'     => 'general_settings',
      'settings'    => 'collapsed_logo_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 25,
          'max' => 150,
      ),
  )
));
/////////////////////////////////////////////////////////

?>