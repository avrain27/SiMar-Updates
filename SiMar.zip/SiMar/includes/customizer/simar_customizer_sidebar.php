<?php
/* ===== Parent: simar_customizer.php ===== */

/* = Settings and Controls for: Communities = */
/////////////////////////////////////////////////////////
$wp_customize->add_setting('sidebar_well_background', array(
	'default' 			=> '#f5f5f5',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'sidebar_well_background', array(
	'label' 	=> 'Well BG Color',
	'section' 	=> 'sidebar_settings'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('sidebar_well_border', array(
	'default' 			=> '#e3e3e3',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'sidebar_well_border', array(
	'label' 	=> 'Well Border Color',
	'section' 	=> 'sidebar_settings'
)));
/////////////////////////////////////////////////////////

?>