<?php
/* ==== Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Gallery = */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('gallery_bg_color', array(
	'default' 			=> '#10a0a5',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'gallery_bg_color', array(
	'label' 	=> 'Gallery Background Color',
	'section' 	=> 'gallery_settings'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('gallery_font_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'gallery_font_color', array(
	'label' 		=> 'h1-Header Font Color',
	'section' 		=> 'gallery_settings'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('gallery_home_image', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'gallery_home_image', array(
   'label'      	=> __( 'Gallery Home Page Image', 'SiMar' ),
   'section'    	=> 'gallery_settings',
   'settings'   	=> 'gallery_home_image',
   'description'	=> __( 'Select a high resolution image for the home page.' )
)));
/////////////////////////////////////////////////////////
?>