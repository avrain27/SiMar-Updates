<?php
/* ==== Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Footer == */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_google', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_google', array(
	'label'			=> __( 'Google Plus Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_facebook', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_facebook', array(
	'label'			=> __( 'Facebook Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_facebook2', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_facebook2', array(
	'label'			=> __( 'Facebook Link 2' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_twitter', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_twitter', array(
	'label'			=> __( 'Twitter Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_instagram', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_instagram', array(
	'label'			=> __( 'Instagram Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_bbb', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_bbb', array(
	'label'			=> __( 'Better Business Bureau Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_sharing', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea'
));	
$wp_customize->add_control('social_sharing', array(
   'label'      => __( 'Social Sharing Shortcode', 'SiMar' ),
   'description'=> 'Shortcode to be used for the social sharing buttons in the footer. (for standard, use [ssba]).',
   'section'    => 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('footer_copyright', array(
	'default'	=> 'The SiMar Group',
	'sanitize_callback' => 'esc_textarea'
));
$wp_customize->add_control('footer_copyright', array(
  'label'      => __('Footer Copyright Company', 'SiMar'),
  'section'    => 'footer_settings',
  'settings'   => 'footer_copyright',
  'type'       => 'radio',
  'choices'    => array(
    'The SiMar Group'    => 'The SiMar Group',
    'WebWise'  => 'WebWise',
  ),
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('footer_info', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags'
));
$wp_customize->add_control('footer_info', array(
   'label'      => __( 'Footer Information', 'SiMar' ),
   'section'    => 'footer_settings',
   'type'		=> 'textarea',
   'description'=> 'Include any information that should be placed in the middle section of the footer above the SiMar Copyright in HTML format INCLUDING hcard tags.'
));
/////////////////////////////////////////////////////////
?>