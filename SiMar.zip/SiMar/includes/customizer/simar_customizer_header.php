<?php
/* === Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Header = */
/////////////////////////////////////////////////////////
$wp_customize->add_setting('misc_toggle', array(
	'default'	 => true
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'misc_toggle', array(
	'label'       => esc_html__( 'Hide Slogan on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_settings',
	'settings'    => 'misc_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('phone_toggle', array(
	'default'	 => false
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'phone_toggle', array(
	'label'       => esc_html__( 'Hide Phone on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_settings',
	'settings'    => 'phone_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('hours_toggle', array(
	'default'	 => true
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'hours_toggle', array(
	'label'       => esc_html__( 'Hide Hours on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_settings',
	'settings'    => 'hours_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('email_toggle', array(
	'default'	 => false
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'email_toggle', array(
	'label'       => esc_html__( 'Hide Email on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_settings',
	'settings'    => 'email_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_bg_color', array(
		'default' 			=> '#fff',
		'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_bg_color', array(
	'label' 	=> 'Header Background Color',
	'section' 	=> 'header_settings'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_font_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_font_color', array(
	'label' 	=> 'Header Font Color',
	'section' 	=> 'header_settings'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_link_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_link_color', array(
	'label' 	=> 'Header Link Color',
	'section' 	=> 'header_settings'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_glyphicon_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_glyphicon_color', array(
	'label' 	=> 'Header Glyphicon Color',
	'section' 	=> 'header_settings'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_logo', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'header_logo', array(
   'label'      => __( 'Client Logo', 'SiMar' ),
   'section'    => 'header_settings',
   'settings'   => 'header_logo' 
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_slogan', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags'
));
$wp_customize->add_control('header_slogan', array(
   'label'      => __( 'Slogan', 'SiMar' ),
   'section'    => 'header_settings',
   'type'		=> 'textarea',
   'description'=> 'Text and/or HTML elements are allowed.'
));
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_telephone', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea'
));	
$wp_customize->add_control('header_telephone', array(
   'label'      => __( 'Phone Number', 'SiMar' ),
   'section'    => 'header_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_telephone_glyphicon', array(
	'default' 			=> 'glyphicon-phone',
	'sanitize_callback' => 'sanitize_html_class'
));
$wp_customize->add_control('header_telephone_glyphicon', array(
   'label'      => __( 'Phone Number Glyphicon', 'SiMar' ),
   'section'    => 'header_settings',
   'description'=> 'Use a valid Glyphicon class name.'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_hours', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags'
));
$wp_customize->add_control('header_hours', array(
   'label'      => __( 'Contact Hours', 'SiMar' ),
   'section'    => 'header_settings',
   'type'		=> 'textarea'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_hours_glyphicon', array(
	'default' 			=> 'glyphicon-calendar',
	'sanitize_callback' => 'sanitize_html_class'
));
$wp_customize->add_control('header_hours_glyphicon', array(
   'label'      => __( 'Contact Hours Glyphicon', 'SiMar' ),
   'section'    => 'header_settings',
   'description'=> 'Use a valid Glyphicon class name.'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_email', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea'
));
$wp_customize->add_control('header_email', array(
   'label'      => __( 'Contact Email', 'SiMar' ),
   'section'    => 'header_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_email_glyphicon', array(
	'default' 			=> 'glyphicon-send',
	'sanitize_callback' => 'sanitize_html_class'
));
$wp_customize->add_control('header_email_glyphicon', array(
   'label'      => __( 'Contact Email Glyphicon', 'SiMar' ),
   'section'    => 'header_settings',
   'description'=> 'Use a valid Glyphicon class name.'
));
 /////////////////////////////////////////////////////////
?>