<?php
function simar_register_customizer_partials( WP_Customize_Manager $wp_customize ) {
 
    // Abort if selective refresh is not available.
    if ( ! isset( $wp_customize->selective_refresh ) ) {
        return;
    }  

    $wp_customize->selective_refresh->add_partial( 'scrolling_gallery', array(
        'selector' => 'section#scrolling-gallery .container',
        'settings' => array( 'scrolling_gallery' )
    ) );
 
    $wp_customize->selective_refresh->add_partial( 'header_logo', array(
        'selector' => 'section#logo',
        'settings' => array( 'header_logo' )
    ) );
 
    $wp_customize->selective_refresh->add_partial( 'community_list', array(
        'selector' => 'section#communities .container',
        'settings' => array( 'community_list' )
    ) );
 
    $wp_customize->selective_refresh->add_partial( 'social_media_links', array(
        'selector' => 'div#social-links',
        'settings' => array( 'social_media_google' )
    ) );
 
    $wp_customize->selective_refresh->add_partial( 'header_info', array(
        'selector' => 'header section#info',
        'settings' => array( 'header_telephone' )
    ) );
 
    $wp_customize->selective_refresh->add_partial( 'gallery_home_image', array(
        'selector' => 'section#gallery .container',
        'settings' => array( 'gallery_home_image' )
    ) );
}

?>