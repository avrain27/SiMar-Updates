<?php
function simar_custom_css(){
	?>

	<style>
		/* ==== Fonts ==== */
		body{ font-family: <?php echo get_theme_mod('body_font_family', '"Helvetica Neue",Helvetica,Arial,sans-serif'); ?> ; }
		.navbar{ font-size: <?php echo get_theme_mod('navigation_font_size', '14').'px'; ?> ; }
		header { font-size: <?php echo get_theme_mod('header_font_size', '14').'px' ?> ;}
		section#gallery h1 { font-size: <?php echo get_theme_mod('h1_font_size', '16').'px'; ?> ; }

		/* ==== Header ==== */
		header { background: <?php echo get_theme_mod('header_bg_color', '#fff') ?> ;}
		header { color: <?php echo get_theme_mod('header_font_color', '#333') ?> ;}
		header a { color: <?php echo get_theme_mod('header_link_color', '#333') ?> ;}
		header div.glyphicon { color: <?php echo get_theme_mod('header_glyphicon_color', '#333') ?> ;}
		img#client_logo{ max-height: <?php echo get_theme_mod('logo_size', '150').'px'; ?> ; }
		section#fixed-scroll.fixed img#client_logo{ max-height: <?php echo get_theme_mod('collapsed_logo_size', '75').'px'; ?> ; }

		/* ===== Nav ====== */
		.navbar-default, .dropdown-menu { 
			background: <?php echo get_theme_mod('nav_bg_color', '#333') ?> !important ;
			border-color: <?php echo get_theme_mod('nav_border_color', '#fff'); ?> !important;
		}
		.navbar a { color: <?php echo get_theme_mod('nav_font_color', '#fff') ?> !important ;}	
		/* convert highlight HEX to RGB */
 		.navbar li.current-menu-item > a, .navbar-default .navbar-nav>.open>a, .navbar-default .open>a:focus, .navbar-default .navbar-nav>.open>a:hover, .dropdown-submenu a:hover { background: <?php echo hex2rgba(get_theme_mod('nav_highlight_color','#fff'), get_theme_mod('nav_highlight_intensity', '25')/100);?> !important;}
		.navbar a:hover { background: <?php echo hex2rgba(get_theme_mod('nav_highlight_color','#fff'),  get_theme_mod('nav_highlight_intensity', '25')/200); ?> !important;}

		/* === Gallery ==== */
		section#gallery, div#fixed-scroll-padder { 
			background: <?php echo get_theme_mod('gallery_bg_color', '#10a0a5') ?>;
			color: <?php echo get_theme_mod('gallery_font_color', '#fff') ?>;
		}

		/* === Communities === */
		section#communities { background: <?php echo get_theme_mod('community_bg_color', '#fff') ?>;}
		section#communities .row:first-child { color: <?php echo get_theme_mod('community_header_color', '#333') ?>;}
		section#communities .row:nth-child(2) { color: <?php echo get_theme_mod('community_font_color', '#333') ?>;}

		/* === Sidebar === */
		#sidebar .well {background: <?php echo get_theme_mod('sidebar_well_background', '#f5f5f5') ?> !important ;}
		#sidebar .well {border-color: <?php echo get_theme_mod('sidebar_well_border', '#e3e3e3') ?> !important ;}
	</style>

	<?php
}
?>