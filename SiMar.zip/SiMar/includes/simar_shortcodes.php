<?php
	/* ================================ */
	/* ==== SIMAR HEADER ELEMENTS ===== */
	/* ================================ */
	// [simar_logo]
	function simar_logo_handler ( $atts ) {
		$a = shortcode_atts( array(
	        'featured' => false,
	    ), $atts );

		return get_client_logo($a['featured']);
	}
	add_shortcode( 'simar_logo', 'simar_logo_handler' );	

	// [simar_header]
	function simar_header_handler ( $atts ) {
		$a = shortcode_atts( array(
	        'type' => null,
	    ), $atts );

	    switch($a['type'])
	    {
	    	case 'Logo':
	    		return get_client_logo();
	    		break;
	    	case 'Phone':
	    		return get_client_header_phone();
	    		break;
	    	case 'Hours':
	    		return get_client_header_hours();
	    		break;
	    	case 'Email':
	    		return get_client_header_email();
	    		break;
	    	case 'Slogan':
	    		return get_client_slogan();
	    		break;
	    }
	}
	add_shortcode( 'simar_header', 'simar_header_handler' );

	// [simar_seo id="id-value"]
	function simar_seo_handler ( $atts ) {
	    $a = shortcode_atts( array(
	        'id' => 'default',
	    ), $atts );

	    return apply_filters("tsmg_crm_seo", $a['id']);
	}
	add_shortcode( 'simar_seo', 'simar_seo_handler' );

	// [simar_client id="id-value"]
	function simar_client_handler ( $atts ) {
	    $a = shortcode_atts( array(
	        'id' => 'default',
	    ), $atts );

	    return apply_filters("tsmg_crm_client", $a['id']);
	}
	add_shortcode( 'simar_client', 'simar_client_handler' );

	// [simar_video]
	function simar_video_handler ( $atts ) {
		$a = shortcode_atts( array(
	        'divi' => null,
	    ), $atts );

		if(apply_filters("tsmg_crm_seo", "video url"))
		{
			$arr = explode("?v=", apply_filters("tsmg_crm_seo", "video url")); 
			ob_start();
			if($a['divi'] == null)
			{
			?>
				<div class="embed-responsive embed-responsive-16by9">
				<iframe class="embed-responsive-item" src="//www.youtube.com/embed/<?php echo $arr[1]; ?>?rel=0"></iframe>
				</div>
			<?php
			}
			else {
				?><iframe src="//www.youtube.com/embed/<?php echo $arr[1]; ?>?rel=0"></iframe><?php
			}
		} # end video link
		return ob_get_clean();
	}
	add_shortcode( 'simar_video', 'simar_video_handler' );

	// [simar_post title="title-value"]
	function simar_post_handler ( $atts ) {
	    $a = shortcode_atts( array(
	        'title' => '',
	        'reveal' => 'false',
	        'divi' => 'false'
	    ), $atts );

	    $class = 'simar_post';
	    $class .= $a['reveal'] == 'true' ? " reveal" : '';

	    $before = "<div class='". $class ."'>";
	    $after = "</div>";

	    if($a['divi'] == 'true')
	    {
	    	$before .= "<div class='et_builder_outer_content' id='et_builder_outer_content'>";
	    	$before .= "<div class='et_builder_inner_content'>";
	    	$after 	.= "</div></div>";
	    }

	    global $post;
    	$args = array( 'post_type' => 'simar_post', 'posts_per_page' => '-1');
		$myposts = get_posts($args);
		foreach ($myposts as $post):
			setup_postdata( $post ); 
			if(get_the_title() == $a['title']):
				$content = get_the_content();
			endif;
		endforeach;
		wp_reset_postdata();
		//$content = remove_paragraphs($content);
		return $before . do_shortcode($content) . $after;
	}
	add_shortcode( 'simar_post', 'simar_post_handler' );

	/* ================================ */
	/* ====== BOOTSTRAP ELEMENTS ====== */
	/* ================================ */

	// [fluid_container]
	function row_full_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(
	        'background' => '',
	        'padding' => '2em 0'
	    ), $atts );
	  	$bg = !empty($a['background']) ? "background: ". $a['background'] ."; " : '';
	  	$padding = !empty($a['padding']) ? "padding: ". $a['padding'] ."; " : '';
	  	//$content = remove_paragraphs($content);
		return '<div class="container-fluid" style="'. $padding . $bg .'"><div class="container"><div class="row">' . do_shortcode($content) . '</div></div></div>';
	}
	add_shortcode( 'row_full', 'row_full_shortcode' );

	// [row]
	function row_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(
			'max_height' => null
		), $atts );
		$style = $a['max_height'] ? 'max-height: ' . $a['max_height'] .' ' : '';
		//$content = remove_paragraphs($content);
		return '<div class="row" style="'.$style.'">' . do_shortcode($content) . '</div>';
	}
	add_shortcode('row', 'row_shortcode');


	// [simar_image]
	function simar_gallery_image_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(
			'featured' => 'false'
		), $atts );
		$src = $a['featured'] == 'true' ? get_the_post_thumbnail_url() : get_theme_mod('gallery_home_image');
		ob_start();
		if(get_theme_mod('gallery_home_image')): ?>
			<div id='slider'><img class="img-responsive" src="<?php echo $src ?>" alt='gallery home image' /></div>
		<?php endif;
		return ob_get_clean();
	}
	add_shortcode('simar_gallery_image', 'simar_gallery_image_shortcode');

	// [reveal]
	function reveal_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(), $atts );
		//$content = remove_paragraphs($content);
		return '<div class="reveal">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'reveal', 'reveal_shortcode' );

	// [col]
	function col_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(
	        'xs' => 10,
	        'sm' => 12,
	        'md' => null,
	        'lg' => null,
	        'xs-offset' => 1,
	        'sm-offset' => 0,
	        'md-offset' => null,
	        'lg-offset' => null,
	        'text-align' => 'justify',
	        'css' => ''
	    ), $atts );
	    $class =  !empty($a['xs']) ? "col-xs-". $a['xs'] ." col-xs-offset-". $a['xs-offset'] . " " : '';
	    $class .= !empty($a['sm']) ? "col-sm-". $a['sm'] ." col-sm-offset-". $a['sm-offset'] . " " : '';
	    $class .= !empty($a['md']) ? "col-md-". $a['md'] ." col-md-offset-". $a['md-offset'] . " " : '';
	    $class .= !empty($a['lg']) ? "col-lg-". $a['lg'] ." col-lg-offset-". $a['lg-offset'] . " " : '';
	    $class .= !empty($a['text-align']) ? "text-xs-". $a['text-align'] . " " : '';
	    $css .= !empty($a['css']) ? $a['css'] . " " : '';

	    //$content = remove_paragraphs($content);
	    return sprintf(
			"<div class='%s' style='%s'>%s</div>",
			esc_attr($class),
			esc_attr($css),
			do_shortcode($content)
	    );
	}
	add_shortcode( 'col', 'col_shortcode' );

	// [well]
	function well_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(
	        'background' => '',
	        'border-color' => '',
	        'color' => '',
	        'text-align' => '',
	    ), $atts );
	    $bg = !empty($a['background']) ? "background: ". $a['background'] ." !important;" : '';
	    $bc = !empty($a['border-color']) ? "border-color: ". $a['border-color'] ." !important;" : '';
	    $col = !empty($a['color']) ? "color: ". $a['color'] ." !important;" : '';
	    $txt = !empty($a['text-align']) ? "text-align: ". $a['text-align'] ." !important;" : '';
		return '<div class="well" style="'. $bg . $bc . $col . $txt .'">' . do_shortcode($content) . '</div>';
	}
	add_shortcode( 'well', 'well_shortcode' );

	// [simar_contact_header]
	function simar_contact_header_shortcode($atts, $content = null)
	{
		$a = shortcode_atts(array(), $atts);
		ob_start();
		?>
			<p>
			Contact us today! We are ready to serve you with all your related needs. We proudly serve the <b><?php echo apply_filters('tsmg_crm_client', 'city') . ', ' . apply_filters('tsmg_crm_client', 'state') ?></b> area and ALL surrounding communities. We are ready now.
			</p>

			<div class='row' id='contact-info'>
					<div class='col-xs-12 col-xs-offset-0 col-md-6 text-xs-justify col-md-offset-0'>
						<!-- Company Name -->
						<div class='info_content'>
							<div class='glyphicon glyphicon-globe'></div>
							<div><?php echo apply_filters("tsmg_crm_client", "business name"); ?></div>
						</div>
						<!-- Address -->
						<div class='info_content'>
							<div class='glyphicon glyphicon-map-marker'></div>
							<div><?php echo apply_filters("tsmg_crm_client", "street address") . "<br />" . apply_filters("tsmg_crm_client", "city state zip"); ?></div>
						</div>
					</div>
				
					<div class='col-xs-12 col-xs-offset-0 col-md-6 text-xs-justify col-md-offset-0'>
						<!-- Phone -->
						<div class='info_content'>
						<div class="glyphicon <?php echo get_theme_mod('header_telephone_glyphicon', 'glyphicon-phone'); ?>"></div> <!-- phone -->
						<div> 
							<div><a href="tel:<?php echo get_client_telephone() ?>"><?php echo get_client_telephone() ?></a></div>
							<?php if(get_client_fax()) echo 'Fax: <a href="tel:'. get_client_fax() .'">'. get_client_fax() .'</a>'; ?> 
						</div>
					</div> 
					<!-- Email -->
						<div class='info_content'>
						<div class="glyphicon <?php echo get_theme_mod('header_email_glyphicon' ,'glyphicon-send'); ?>"></div><!-- email -->
						<div> 
							<?php 
								foreach( get_client_email() as $e ){
									echo '<div><a href="mailto:'. $e .'">'. $e .'</a></div>'; 
								}
							?>
						</div>
					</div> 
					</div>

			</div>
		<?php
		return ob_get_clean();
	}
	add_shortcode('simar_contact_header', 'simar_contact_header_shortcode');
	
	// [simar_contact]
	function simar_contact_shortcode( $atts, $content = null ) {
		$a = shortcode_atts( array(), $atts );
		$content = remove_paragraphs($content);
		ob_start();
		?>
			<div class='row well well-sm' id='contact-form'><?php echo do_shortcode($content) ?></div>
		<?php
		return ob_get_clean();
	}
	add_shortcode('simar_contact', 'simar_contact_shortcode');

	function simar_map_handler($atts, $content = null)
	{
		$a = shortcode_atts( array(
			'ratio' => '16by9'
		), $atts );
		$addr = str_replace(" ",'+', apply_filters('tsmg_crm_client', 'street address') . ',' . apply_filters('tsmg_crm_client', 'city state zip'));
		ob_start();
		$a['ratio'] = ($a['ratio'] == "16by9" || $a['ratio'] == "4by3") ? $a['ratio'] : '16by9'; // sanity check
		?>
			<div class='embed-responsive embed-responsive-<?php echo $a["ratio"]; ?>'>
			<iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCJbOfyUQqJMGdNMgWXrWcPDMfM-B47bgw&q=<?php echo $addr; ?>"  frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		<?php
		return ob_get_clean();
	}
	add_shortcode('simar_map', 'simar_map_handler');

	/* Remove <p> tags */
	function remove_paragraphs ( $content ) {
			$content = str_ireplace( '<p>','',$content );
			$content = str_ireplace( '</p>','',$content );
			return $content;
	}

?>