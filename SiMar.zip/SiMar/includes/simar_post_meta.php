<?php
function simar_add_meta_boxes( $post ) {

    // Get the page template post meta
    $page_template = get_post_meta( $post->ID, '_wp_page_template', true );
    // If the current page uses our specific
    // template, then output our custom metabox
    if ( 'page_contact.php' == $page_template ) {
        add_meta_box(
            'simar-custom-metabox', // Metabox HTML ID attribute
            'Special Post Meta', // Metabox title
            'simar_page_template_metabox', // callback name
            'page', // post type
            'normal', // context (advanced, normal, or side)
            'default' // priority (high, core, default or low)
        );
    }
}
// Make sure to use "_" instead of "-"
add_action( 'add_meta_boxes_page', 'simar_add_meta_boxes' );


function simar_page_template_metabox() {
    // Define the meta box form fields here
    global $post;
    $post_id = $post->ID;
    ?>
    <p>
        <label for="simar-contact-shortcode">Contact Form Shorcode</label>
        <br />
        <input type="text" name="simar-contact-shortcode" id="simar-contact-shortcode" value="<?php echo esc_attr( get_post_meta( $post->ID, 'simar-contact-shortcode', true ) ); ?>" size="50" />
        <br />
        <label for="simar-contact-map">Contact Map: Embed Source Code (include iframe tags)</label>
        <br />
        <input style='width: 340px;' type="text" name="simar-contact-map" id="simar-contact-map" value="<?php echo esc_html(get_post_meta( $post->ID, 'simar-contact-map', true )); ?>"/>
       
    </p>
  <?php
}


function simar_save_custom_post_meta() {
    // Sanitize/validate post meta here, before calling update_post_meta()
    global $post;
    $post_id = $post->ID;
    /* Get the posted data and sanitize it for use as an HTML class. */
    $shortcode_value = ( isset( $_POST['simar-contact-shortcode'] ) ? esc_textarea($_POST['simar-contact-shortcode']) : '' );
    $map_value = ( isset( $_POST['simar-contact-map'] ) ? esc_html($_POST['simar-contact-map']) : '' );

    if($shortcode_value)
        update_post_meta( $post_id, 'simar-contact-shortcode', $shortcode_value );
    else
        delete_post_meta( $post_id, 'simar-contact-shortcode', $shortcode_value );

    if($map_value)
        update_post_meta( $post_id, 'simar-contact-map', $map_value );
    else
        delete_post_meta( $post_id, 'simar-contact-map', $map_value );
}
add_action( 'publish_page', 'simar_save_custom_post_meta' );
add_action( 'draft_page', 'simar_save_custom_post_meta' );
add_action( 'future_page', 'simar_save_custom_post_meta' );

?>