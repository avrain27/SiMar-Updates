<?php
/**
 * Twenty Sixteen Customizer functionality
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.2
 */
/* CLASS DECLARATIONS */
require_once(get_template_directory().'/includes/customizer/classes/WP_Customize_Range_Control.php');

/* THEME CUSTOMIZE SETTINGS / DECLARATIONS */
function simar_customize_register( $wp_customize ) {

	// ================================================== //
	// ==================== Pannels ===================== //
	// ================================================== //
	$wp_customize->add_panel( 'home_page', array(
	  'title' => __( 'Home Page Specifics' )
	));

	$wp_customize->add_panel( 'client_seo', array(
	  'title' => __( 'Client SEO' )
	));

	// ================================================== //
	// =================== Sections ===================== //
	// ================================================== //
	$wp_customize->add_section('general_settings', array(
		'title' => 'General Settings'
	));

	$wp_customize->add_section('header_settings', array(
		'title' => 'Header'
	));

	$wp_customize->add_section('nav_settings', array(
		'title' => 'Navigation'
	));

	$wp_customize->add_section('gallery_settings', array(
		'title' => 'Gallery'
	));

	$wp_customize->add_section('home_page_color_scheme', array(
		'title' => 'Color Scheme',
		'panel' => 'home_page'
	));

	$wp_customize->add_section('home_page_scrolling_gallery', array(
		'title' => 'Scrolling Gallery',
		'panel' => 'home_page'
	));

	$wp_customize->add_section('community_settings', array(
		'title' => 'Communities',
		'panel' => 'client_seo'
	));

	$wp_customize->add_section('client_info', array(
		'title' => 'Client Info',
		'panel' => 'client_seo'
	));

	$wp_customize->add_section('footer_settings', array(
		'title' => 'Footer & Social Media'
	));

	// ================================================== //
	// =================== Includes ===================== //
	// ================================================== //
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_general.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_header.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_nav.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_gallery.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_home_page.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_client_seo.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_footer.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_partials.php');

}

?>