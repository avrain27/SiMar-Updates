<?php
/**
 * Twenty Sixteen Customizer functionality
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.2
 */
/* CLASS DECLARATIONS */
require_once(get_template_directory().'/includes/customizer/classes/WP_Customize_Range_Control.php');

/* THEME CUSTOMIZE SETTINGS / DECLARATIONS */
function simar_customize_register( $wp_customize ) {

	// ================================================== //
	// ==================== Pannels ===================== //
	// ================================================== //
	$wp_customize->add_panel( 'header', array(
	  'title' => __( 'Header' )
	));

	// ================================================== //
	// =================== Sections ===================== //
	// ================================================== //
	$wp_customize->add_section('font_settings', array(
		'title' => 'Font Settings'
	));

	$wp_customize->add_section('header_ga', array(
		'title' => 'Google Analytics',
		'panel' => 'header'
	));
	$wp_customize->add_section('header_collapse', array(
		'title' => 'Header-Collapse (Animation)',
		'panel' => 'header'
	));
	$wp_customize->add_section('header_color_scheme', array(
		'title' => 'Color Scheme',
		'panel' => 'header'
	));
	$wp_customize->add_section('header_images', array(
		'title' => 'Logo / Favicon',
		'panel' => 'header'
	));
	$wp_customize->add_section('header_info', array(
		'title' => 'Information Section',
		'panel' => 'header'
	));


	$wp_customize->add_section('nav_settings', array(
		'title' => 'Navigation'
	));

	$wp_customize->add_section('gallery_settings', array(
		'title' => 'Gallery'
	));

	$wp_customize->add_section('community_settings', array(
		'title' => 'Communities'
	));

	$wp_customize->add_section('footer_settings', array(
		'title' => 'Footer & Social Media'
	));

	$wp_customize->add_section('sidebar_settings', array(
		'title' => 'Sidebar Settings'
	));

	// ================================================== //
	// =================== Includes ===================== //
	// ================================================== //
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_font.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_header.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_nav.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_gallery.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_communities.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_footer.php');
	require_once(get_template_directory() . '/includes/customizer/simar_customizer_sidebar.php');

}

?>