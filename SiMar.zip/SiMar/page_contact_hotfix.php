<?php
/**
 * Template Name: Contact Page HOTFIX
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<div class='col-xs-10 col-xs-offset-1 col-md-8 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>

				<!-- Contact Form -->
				<?php 
					$contact_shortcode = str_replace('&quot;', '"', get_post_meta( get_the_ID(), 'simar-contact-shortcode', true ));
					echo do_shortcode('[simar_contact]'.$contact_shortcode.'[/simar_contact]');
				?>
			</div>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>