<section id='sidebar' class='col-xs-10 col-xs-offset-1 col-md-4 col-md-offset-0'>
	<?php 
		dynamic_sidebar('simar_sidebar');
	?>
</section>