<section id='communities' class='container-fluid'>
	<div class='container'>
	<div class='row'>
		<div class='col-xs-12 h4 text-xs-center text-sm-left'>Primary Communities Served</div>
	</div>
	<div class='row'>
		<?php get_community_list(); ?>
	</div>
	</div>
</section>

<footer class='container-fluid'>
	<div class='container'>
	<div class='row vertical-align-md text-center'>
		<div id='social-sharing' class='col-md-2 text-center'>
			<?php 
				if(get_theme_mod("social_sharing"))
					echo do_shortcode(get_theme_mod("social_sharing")); 
			?>
		</div>
		<div id='company-info' class='col-md-7 text-center'>
			<?php get_footer_company_info(); ?>
			Copyright &copy <?php echo date('Y'); ?> <a target='_blank' href='http://thesimargroup.com'>The SiMar Group</a>
			<div id='nav-container'><?php wp_nav_menu( array('theme_location' => 'Footer Menu')); ?> | <a class='invert_a' href='<?php echo apply_filters("tsmg_crm_client", "youtube url"); ?>' target="_blank">Youtube</a></div>
		</div>
		<div id='social-links' class='col-md-3 text-center'><?php get_social_media_links(); ?></div>
	</div>
	</div>
</footer>

</div> <!-- wrapper -->
<?php if(get_theme_mod("header_google_analytics")) : echo get_theme_mod("header_google_analytics"); endif; ?>
<script>
  var loadDeferredStyles = function() {
    var addStylesNode = document.getElementById("deferred-styles");
    var replacement = document.createElement("div");
    replacement.innerHTML = addStylesNode.textContent;
    document.body.appendChild(replacement)
    addStylesNode.parentElement.removeChild(addStylesNode);
  };
  var loadAutoptimizeStyles = function() {
    var addStylesNode = document.getElementById("aonoscrcss");
    var replacement = document.createElement("div");
    replacement.innerHTML = addStylesNode.textContent;
    document.body.appendChild(replacement)
    addStylesNode.parentElement.removeChild(addStylesNode);
  };
  var raf = requestAnimationFrame || mozRequestAnimationFrame ||
      webkitRequestAnimationFrame || msRequestAnimationFrame;
  if (raf) raf(function() { window.setTimeout(loadDeferredStyles, 0); });
  else window.addEventListener('load', loadDeferredStyles);
</script>
<noscript id="deferred-styles">
 <!-- <link rel="stylesheet" type="text/css" href="<?php #echo get_template_directory_uri() . '/bootstrap/css/bootstrap.min.css' ?>"/> -->
</noscript>
<script>
(function($) {
	$(document).ready(function(){
		$('.flip_panel.hover').on('mouseenter', function() {
			if (!$(this).hasClass('flip'))
				$(this).addClass('flip');
		});
		$('.flip_panel.hover').on('touch, click', function() {
			if (!$(this).hasClass('flip'))
				$(this).addClass('flip');
			else
				$(this).removeClass('flip');
		});
		$('.flip_panel.hover').on('mouseleave', function() {
			if ($(this).hasClass('flip'))
				$(this).removeClass('flip');
		});
	});
})(jQuery);
</script>
	<?php wp_footer(); ?>
</body>
</html>