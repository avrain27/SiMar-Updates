<?php
/**
 * Template Name: PageSpeed
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.3.0
 */
 ?>

 <?php get_header(); ?>

<?php 
	# Curl request for Google PageSpeeds API
	# Config Variables
	# $url = get_home_url();
	$url = 'http://mikeandsonasphalt.com/';
	$strategy = 'mobile';
	$key = 'AIzaSyCJbOfyUQqJMGdNMgWXrWcPDMfM-B47bgw';

	# Initializer cURL
	echo 'https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$url.'&strategy='.$strategy.'&key='.$key;
	$ch = curl_init('https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$url.'&strategy='.$strategy.'&key='.$key);
	# Disable SSL verification
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	# Will return the response, if false it print the response
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	# Get Result
	$result = curl_exec($ch);
	# Close
	curl_close($ch);
	# Dump Result
	if (!$result)
		echo "<div class='alert alert-danger text-xs-center'>Failed to Retrieve Google PageSpeed Data.</div>";
	else
	{
		$ps = json_decode($result, true);
		var_dump($ps);
		echo $ps['ruleGroups']['SPEED']['score'];
	}
?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-10 col-xs-offset-1 col-md-12 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>

				<div class="table-responsive">
					<table class="table table-bordered">
						<thead><tr>
							<th>Client</th>
							<th>Online</th>
							<th>Mobile PageSpeed</th>
							<th>Desktop Pagespeed</th>
							<th>PHP Error</th>
						</tr></thead>
						<tbody><tr>
							<th>1</th>
							<td class='success'></td>
							<td class='warning'></td>
							<td class='danger'></td>
							<td></td>
						</tr></tbody>
					</table>
				</div>
				
			</section>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>