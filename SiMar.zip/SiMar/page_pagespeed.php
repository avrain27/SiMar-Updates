<?php
/**
 * Template Name: PageSpeed
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.3.3.0
 */
 ?>

 <?php get_header(); ?>

<?php 
	/*	
	# Curl request for Google PageSpeeds API
	# Config Variables
	# $url = get_home_url();
	$url = 'http://mikeandsonasphalt.com/';
	$strategy = 'mobile';

	# Initializer cURL
	echo 'https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$url.'&strategy='.$strategy.'&key='.$key;
	$ch = curl_init('https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$url.'&strategy='.$strategy.'&key='.$key);
	# Disable SSL verification
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	# Will return the response, if false it print the response
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	# Get Result
	$result = curl_exec($ch);
	# Close
	curl_close($ch);
	# Dump Result
	if (!$result)
		echo "<div class='alert alert-danger text-xs-center'>Failed to Retrieve Google PageSpeed Data.</div>";
	else
	{
		$ps = json_decode($result, true);
		var_dump($ps);
		echo $ps['ruleGroups']['SPEED']['score'];
	}
	*/
	# CHECK FOR RUN REQUEST
	if (isset($_POST['runSpeeds']))
	{
		# GoogleAPI key
		$key = 'AIzaSyCJbOfyUQqJMGdNMgWXrWcPDMfM-B47bgw';
		# array of all urls in Our Network
		$urls = array(
			"http://360salononline.com",
			"http://AlbionElectric.com",
			"http://AllImportsAutoParts.com",
			"http://AprilsAntiquesAndMore.com",
			"http://artunlimitedgallery.net",
			"http://SecurityASI.com",
			"http://BaresSportsShop.com",
			"http://Bilt-RiteConstruction",
			"http://BloughHardwoods.com",
			"http://BransonBuilderInc.com",
			"http://BriansDoItAllHandyman.com",
			"http://cmhomesinc.com",
			"http://ccmcf.com",
			"http://ww.CapitolLightingInc",
			"http://ClassicPoolMI.com",
			"http://CleryFence.com",
			"http://HomeInspectionMI.com",
			"http://ddasphaltspecialists.com",
			"http://DanoCeramicTile.com",
			"http://ww.DavisGlassAndScreen",
			"http://Dible-Glasser",
			"http://dravesautocenter.com",
			"http://DRMILC.com",
			"http://East-End",
			"http://EJandSonsMoving.com",
			"http://Equipment-SolutionsInc",
			"http://FairgroveOil.com",
			"http://FiresideEssentials.com",
			"http://FlashSanitation.com",
			"http://ForkelFence.com",
			"http://Fowlerorgan.com",
			"http://GibsonsBookStore.net",
			"http://GGLCo.com",
			"http://GradeAGutterSystems.com",
			"http://GrandTraverseMotel.NET",
			"http://GroundsCoffeeMidland.com",
			"http://HerterMusicCenter.com",
			"http://HomeCraftBuilding.com",
			"http://InnovativeHydroponicSupply.com",
			"http://lansingmedicalcardclinic.com",
			"http://InvisionBoatworks.com",
			"http://JAndMHauling.com",
			"http://JandRCoins.com",
			"http://JJFurniture.com",
			"http://ww.KGBBuilders",
			"http://KeyesAutoBody.com",
			"http://LansingTransmission.com",
			"http://lynnmorganstudios.com",
			"http://MaloneyCarpetOne.com",
			"http://mlagbag.com",
			"http://MartinAndSonsReglazing.com",
			"http://MTCHelp.com",
			"http://midstate-towing",
			"http://MidMichiganPonds.com",
			"http://MikeAndSonAsphalt.com",
			"http://MintCityEXC.com",
			"http://MotherTeresaHouse.org",
			"http://ww.PatsAutoInc",
			"http://PeteVandenBergBuilder.com",
			"http://PTCDeWitt.com",
			"http://PlumbersPortableToilets.com",
			"http://PriorityAutoBodyInc.com",
			"http://QualityTireLansing.com",
			"http://RSTruckandDiesel.com",
			"http://bcradiocom.com",
			"http://DavisAutoParts.com",
			"http://RicksPortables.com",
			"http://ARooterManMI.com",
			"http://rostcleaning.com",
			"http://ww.ScharnweberWellDrilling",
			"http://SchlegelSand.com",
			"http://ScottishRiteRental.com",
			"http://SeeseWellDrilling.com",
			"http://ShieldsAndSons1912.com",
			"http://SSPrintinc.com",
			"http://ww.SmithsMachineGrinding",
			"http://StarrRemodeling.com",
			"http://StartingPointsChildCare.com",
			"http://TheHorizonSeniorLiving.com",
			"http://thelightbulbco.com",
			"http://TheNauticalNeedle.com",
			"http://Valley-Obgyn",
			"http://weddingdazeonline.com",
			"http://WestSideDecoratingCenter.com",
			"http://WheelersMarine.com",
			"http://willsielumber.com",
			"http://woodreviver.com"
			);
		# all cURL instances
		$handles = array();
		foreach($urls as $u)
		{
			# Initialize Mobile and Desktop cURLs
			$ch_mobile = curl_init('https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$u.'&strategy=mobile&key='.$key);
			$ch_desktop = curl_init('https://www.googleapis.com/pagespeedonline/v2/runPagespeed?url='.$u.'&strategy=desktop&key='.$key);
			# Disable SSL verification
			curl_setopt($ch_mobile, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch_desktop, CURLOPT_SSL_VERIFYPEER, false);
			# Will return the response, if false it print the response
			curl_setopt($ch_mobile, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch_desktop, CURLOPT_RETURNTRANSFER, true);
			# Push both instances back to $handles
			$handles[] = $ch_mobile;
			$handles[] = $ch_desktop;
		}
		# Initialize multi_cURL
		$mh = curl_multi_init();
		# Add all handles
		foreach($handles as $h)
			curl_multi_add_handle($mh, $h);
		# Execute the handles
		do {
			curl_multi_exec($mh, $running);
		} while ($running > 0);
		# Get results
		$PageSpeeds = array();
		for($i = 0; $i < count($handles); $i += 2)
		{
			$m = json_decode(curl_multi_getcontent($handles[$i]), true);
			$d = json_decode(curl_multi_getcontent($handles[$i+1]), true);
			if (!m || !d)
			{
				echo "<div class='alert alert-danger text-xs-center'>Failed to Retrieve Google PageSpeed Data.</div>";
			}
			else
			{
				$name = explode("| ", $m['title']);
				$PageSpeeds[] = array($name[1], $m['ruleGroups']['SPEED']['score'], $d['ruleGroups']['SPEED']['score']);
			}
		}
		# Close handles
		foreach($handles as $h)
			curl_multi_remove_handle($mh, $h);
		# Close multi_cURL
		curl_multi_close($mh);

		$to_print = "";
		foreach($PageSpeeds as $p)
		{
			$class_m = ($p[1] >= 85) ? "success" : (($p[1] < 80) ? "danger" : "warning");
			$class_d = ($p[2] >= 85) ? "success" : (($p[2] < 80) ? "danger" : "warning");
			$to_print .= "<tr>";
			$to_print .= "<td>$p[0]</td>";
			$to_print .= "<td></td>";
			$to_print .= "<td class='$class_m'>$p[1]</td>";
			$to_print .= "<td class='$class_d'>$p[2]</td>";
			$to_print .= "</tr>";
		}
	} # END RUN CHECK
?>

<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-10 col-xs-offset-1 col-md-12 text-xs-justify col-md-offset-0'>
				<?php while( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
				<?php endwhile; ?>

				<div class="table-responsive">
					<table class="table table-bordered">
						<thead><tr>
							<th>Client</th>
							<th>Online</th>
							<th>Mobile PageSpeed</th>
							<th>Desktop Pagespeed</th>
						</tr></thead>
						<tbody>
							<?php echo $to_print; ?>
						</tbody>
					</table>
				</div>
				<?php if(!isset($_POST["runSpeeds"]))
				{
					?>
						<form method="POST" action="">
							<input type='submit' name='runSpeeds' class="btn btn-success btn-lg btn-block" value="Run PageSpeed Diagnostic on ALL Client Sites" />
						</form>
					<?php
				}
				?>
				
			</section>
		</div>
		</div>
	</article>

</main>

<?php get_footer(); ?>