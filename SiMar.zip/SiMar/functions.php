<?php
show_admin_bar(false);

function register_dependencies()
{
    // jQuery
    wp_deregister_script('jquery');
    wp_register_script('jquery', includes_url('/js/jquery/jquery.js'), false, null, true);  
    wp_enqueue_script('jquery'); 
 	// visual fix for page loads
    wp_enqueue_script( 'simar-load', get_template_directory_uri() . '/includes/simar_load_page.js', array(), true, true);
    wp_enqueue_script( 'simar-navigation', get_template_directory_uri() . '/includes/simar_navigation.js', array(), true, true);
    //bootstrap 
    wp_enqueue_style( 'bootstrapstyle', get_template_directory_uri() . '/bootstrap/css/bootstrap.min.css' );
    wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/bootstrap/js/bootstrap.min.js', array('jquery'), true, true);
    //scroll-reveal
   wp_enqueue_script( 'scrollreveal-master', get_template_directory_uri() . '/includes/scrollreveal-master/dist/scrollreveal.min.js', array(), true, true);
   wp_enqueue_script( 'simar-scrollreveal', get_template_directory_uri() . '/includes/simar_scrollreveal.js', array('scrollreveal-master'), true, true);

}
add_action('wp_enqueue_scripts', 'register_dependencies');

function SiMar_Scripts() 
{
    // style sheets
	wp_enqueue_style( 'style', get_stylesheet_uri() );
    // menu
	register_nav_menu('Main Menu', 'Main Menu used in the main site navigation.');
	register_nav_menu('Footer Menu', 'Footer Menu used in the footer (Generally: Site Map, Our Network, Youtube).');
}
SiMar_Scripts();

// Custom POST Types
add_action( 'init', 'create_post_type' );
function create_post_type() {
  // Announcements
  register_post_type( 'simar_post',
    array(
      'labels' => array(
        'name' => __( 'Simar Posts' ),
        'singular_name' => __( 'Simar Post' )
      ),
      'public' => true,
      'has_archive' => true,
      'menu_icon' => 'dashicons-format-aside'
    )
  );
}

// Shortcodes
include(get_template_directory().'/includes/simar_shortcodes.php');

// Widgets
include(get_template_directory().'/includes/simar_widgets.php');

// Divi Builder Custom Post Type
function my_et_builder_post_types( $post_types ) {
    $post_types[] = 'simar_post';
     
    return $post_types;
}
add_filter( 'et_builder_post_types', 'my_et_builder_post_types' );



// Post Thumbnails
add_theme_support( 'post-thumbnails' ); 

include(get_template_directory().'/includes/simar_hex2rgba.php');
include(get_template_directory().'/includes/simar_update_theme.php');
include(get_template_directory().'/includes/woo_commerce.php');
include(get_template_directory().'/includes/simar_post_meta.php');
// Register Custom Navigation Walker
require_once(get_template_directory().'/includes/wp_bootstrap_navwalker.php');

// parts
include(get_template_directory() . '/parts/community_list.php');
include(get_template_directory() . '/parts/footer_company_info.php');
include(get_template_directory() . '/parts/header/header_parts.php');
include(get_template_directory() . '/parts/social_media_links.php');

?>