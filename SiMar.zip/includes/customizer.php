<?php
  function simar_customizer_register($wp_customize) {
    //First Page Section
    $wp_customize->add_section('footer', array(
      'title' => __('Footer Options', 'simar'),
      'description' => sprintf(__('Footer area Fields', 'simar')),
      'priority' => 135
    ));

    //video two youtube url
    $wp_customize->add_setting('communities_heading', array(
      'default' => __('Primary Communities Served', 'simar'),
      'type' => 'theme_mod'
    ));

    $wp_customize->add_control('communities_heading', array(
      'label' => __('Communities Heading', 'simar'),
      'section' => 'footer',
      'priority' => 1
    ));
  }

  add_action('customize_register', 'simar_customizer_register');
