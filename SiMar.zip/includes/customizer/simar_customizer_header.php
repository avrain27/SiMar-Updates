<?php
/* === Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Header = */
/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_google_analytics', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags'
));
$wp_customize->add_control('header_google_analytics', array(
   'label'      => __( 'Google Analytics Script', 'SiMar' ),
   'section'    => 'header_ga',
   'type'		=> 'textarea',
   'description'=> 'Post the full <script></script> in the field to add to the header!'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('misc_toggle', array(
	'default'	 => true,
	'transport'	 => 'postMessage'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'misc_toggle', array(
	'label'       => esc_html__( 'Hide Slogan on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_collapse',
	'settings'    => 'misc_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('phone_toggle', array(
	'default'	 => false,
	'transport'	 => 'postMessage'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'phone_toggle', array(
	'label'       => esc_html__( 'Hide Phone on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_collapse',
	'settings'    => 'phone_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('hours_toggle', array(
	'default'	 => true,
	'transport'	 => 'postMessage'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'hours_toggle', array(
	'label'       => esc_html__( 'Hide Hours on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_collapse',
	'settings'    => 'hours_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('email_toggle', array(
	'default'	 => false,
	'transport'	 => 'postMessage'
));

$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'email_toggle', array(
	'label'       => esc_html__( 'Hide Email on Header Collapse'),
	'description' => esc_html__( 'Occurs when scrolling down the page' ),
	'section'     => 'header_collapse',
	'settings'    => 'email_toggle',
	'type'        => 'checkbox'
) ) );
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_bg_color', array(
		'default' 			=> '#fff',
		'sanitize_callback' => 'sanitize_hex_color',
		'transport' 		=> 'postMessage'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_bg_color', array(
	'label' 	=> 'Header Background Color',
	'section' 	=> 'header_color_scheme'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_font_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' 		=> 'postMessage'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_font_color', array(
	'label' 	=> 'Header Font Color',
	'section' 	=> 'header_color_scheme'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_link_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' 		=> 'postMessage'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_link_color', array(
	'label' 	=> 'Header Link Color',
	'section' 	=> 'header_color_scheme'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_glyphicon_color', array(
	'default' 			=> '#333',
	'sanitize_callback' => 'sanitize_hex_color',
	'transport' 		=> 'postMessage'
));	
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'header_glyphicon_color', array(
	'label' 	=> 'Header Glyphicon Color',
	'section' 	=> 'header_color_scheme'
)));	
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('client_favicon', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_url_raw',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'client_favicon', array(
   'label'      => __( 'Client Favicon', 'SiMar' ),
   'section'    => 'header_images',
   'settings'   => 'client_favicon' 
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_logo', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_url_raw',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'header_logo', array(
   'label'      => __( 'Client Logo', 'SiMar' ),
   'section'    => 'header_images',
   'settings'   => 'header_logo' 
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('logo_size', array(
  'default'           => 150,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'logo_size',
  array(
      'label'       => __('Logo Size'),
      'section'     => 'header_images',
      'settings'    => 'logo_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 25,
          'max' => 300,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('collapsed_logo_size', array(
  'default'           => 75,
  'sanitize_callback'   => 'absint',
   'transport'           => 'postMessage'
)); 
$wp_customize->add_control(new WP_Customize_Range_Control(
  $wp_customize,
  'collapsed_logo_size',
  array(
      'label'       => __('Collapsed Logo Size'),
      'section'     => 'header_images',
      'settings'    => 'collapsed_logo_size',
      'description' => __('pixels.'),
      'input_attrs' => array(
          'min' => 25,
          'max' => 150,
      ),
  )
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_slogan', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control('header_slogan', array(
   'label'      => __( 'Slogan', 'SiMar' ),
   'section'    => 'header_info',
   'type'		=> 'textarea',
   'description'=> 'Text and/or HTML elements are allowed.'
));
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_telephone', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control('header_telephone', array(
   'label'      => __( 'Phone Number', 'SiMar' ),
   'section'    => 'header_info'
));
/////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_fax', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea'
));
$wp_customize->add_control('header_fax', array(
   'label'      => __( 'Fax Number', 'SiMar' ),
   'section'    => 'header_info'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_telephone_glyphicon', array(
	'default' 			=> 'glyphicon-phone',
	'sanitize_callback' => 'sanitize_html_class'
));
$wp_customize->add_control('header_telephone_glyphicon', array(
   'label'      => __( 'Phone Number Glyphicon', 'SiMar' ),
   'section'    => 'header_info',
   'description'=> 'Use a valid Glyphicon class name.'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_hours', array(
	'default' 			=> '',
	'sanitize_callback' => 'force_balance_tags',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control('header_hours', array(
   'label'      => __( 'Contact Hours', 'SiMar' ),
   'section'    => 'header_info',
   'type'		=> 'textarea'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_hours_glyphicon', array(
	'default' 			=> 'glyphicon-calendar',
	'sanitize_callback' => 'sanitize_html_class'
));
$wp_customize->add_control('header_hours_glyphicon', array(
   'label'      => __( 'Contact Hours Glyphicon', 'SiMar' ),
   'section'    => 'header_info',
   'description'=> 'Use a valid Glyphicon class name.'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_email', array(
	'default' 			=> '',
	'sanitize_callback' => 'esc_textarea',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control('header_email', array(
   'label'      => __( 'Contact Email', 'SiMar' ),
   'section'    => 'header_info'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('header_email_glyphicon', array(
	'default' 			=> 'glyphicon-send',
	'sanitize_callback' => 'sanitize_html_class',
	'transport'			=> 'postMessage'
));
$wp_customize->add_control('header_email_glyphicon', array(
   'label'      => __( 'Contact Email Glyphicon', 'SiMar' ),
   'section'    => 'header_info',
   'description'=> 'Use a valid Glyphicon class name.'
));
 /////////////////////////////////////////////////////////
?>