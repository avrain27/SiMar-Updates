<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<?php wp_head() ?>
</head>

<body style='display: none;'>
		
<header class='container-fluid'>
<div class='container'>
<div class='row vertical-align-sm text-xs-center h4'>
	<section id='logo' class='col-sm-4 col-sm-offset-0 col-xs-8 col-xs-offset-2 text-md-left' >
		<?php if(get_theme_mod('header_logo')): ?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<img src="<?php echo get_theme_mod('header_logo') ?>" class='img-responsive dark-gray' alt='company logo''/>
			</a>
		<?php endif; ?>
	</section>

	<section id='misc' class='col-sm-4 col-sm-offset-0 col-xs-8 col-xs-offset-2 text-md-center'>
		<?php echo get_theme_mod('header_slogan'); ?>
	</section>

	<section id='info' class='col-sm-4 col-sm-offset-0 col-xs-8 col-xs-offset-2 text-sm-right'>
		<?php if(get_theme_mod('header_telephone')): ?>
			<div>
				<span class="glyphicon <?php echo get_theme_mod('header_telephone_glyphicon', 'glyphicon-phone'); ?>"></span> <!-- phone -->
				<a href="tel: <?php echo get_theme_mod('header_telephone') ?>">
				<?php echo get_theme_mod('header_telephone') ?>
				</a>
			</div> 
		<?php endif; ?>
		<?php if(get_theme_mod('header_hours')): ?>
			<div>
				<span class="glyphicon <?php echo get_theme_mod('header_hours_glyphicon', 'glyphicon-calendar'); ?>"></span><!-- hours -->
				<?php echo get_theme_mod('header_hours') ?>
			</div> 
		<?php endif; ?>
		<?php if(get_theme_mod('header_email')): ?>
			<div>
				<span class="glyphicon <?php echo get_theme_mod('header_email_glyphicon' ,'glyphicon-send'); ?>"></span><!-- email -->
				<a href="mailto:<?php echo get_theme_mod('header_email') ?>">
					<?php echo get_theme_mod('header_email') ?>
				</a>
			</div> 
		<?php endif; ?>
	</section>
</div>
</div>
</header>

<nav class='container-fluid'>
	<div class='container'>
	<div class='row'>
		<div class='col-xs-12'>
		<?php wp_nav_menu( array('theme_location' => 'Main Menu')); ?>
		</div>
	</div>
	</div>
</nav>

<section id='gallery' class='container-fluid'>
	<div class='container'>
	<div class='row'>
	<div class='col-xs-12'>
		<div id='slider'>
			<?php if(get_theme_mod('gallery_home_image')): ?>
				<img src="<?php echo get_theme_mod('gallery_home_image') ?>" alt='gallery home image'/>
			<?php endif; ?>
		</div>
		<h1>H1 Header Tag Here</h1>
	</div>
	</div>
	</div>
</section>