<?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>

	<main role='main'>

		<article id='content' class='container-fluid'>
			<div class='container'>
			<div class='row text-xs-center'>
				<section class='col-xs-12'>
					<?php the_content(); ?>
				</section>
			</div>
			</div>
		</article>		

		<section id='video' class='container-fluid'>
			<div class='container'>
			<div class='row text-xs-center'>
				<section class='col-xs-8 col-xs-offset-2 '>
					<div class="embed-responsive embed-responsive-16by9">
 						<iframe class="embed-responsive-item" src="//www.youtube.com/embed/7kiMjJ01X6Q?rel=0"></iframe>
					</div>
				</section>
			</div>
			</div>
		</section>
		
		<section id='page-excerpts' class='container-fluid'>
			<div class='container'>
			<div class='row'>
				<div class='col-md-4 col-md-offset-0 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 page-excerpt'>
					<h3 class='well' style='color: #353560'>About Us</h3>
					<p>
					filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler
					</p>
					<a href='' class='btn btn-default btn-xs btn-block'>Read More!</a>
				</div>
				<div class='col-md-4 col-md-offset-0 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 page-excerpt'>
					<h3 class='well' style='color: #353560'>About Us</h3>
					<p>
					filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler
					</p>
					<a href='' class='btn btn-default btn-xs btn-block'>Read More!</a>
				</div>
				<div class='col-md-4 col-md-offset-0 col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 page-excerpt'>
					<h3 class='well' style='color: #353560'>About Us</h3>
					<p>
					filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler filler
					</p>
					<a href='' class='btn btn-default btn-xs btn-block'>Read More!</a>
				</div>
			</div>
			</div>
		</section>

		<article id='features' class='container-fluid text-xs-center'>
			<div class='container'>
			<div class='row'>
				<section id='announcements' class='col-xs-8 col-xs-offset-2 col-md-5 col-md-offset-0'>
					<h3>announcements</h3>
				</section>
				<section id='testimonials' class='col-xs-8 col-xs-offset-2 col-md-5 col-md-offset-2'>
					<h3>testimonials</h3>
				</section>
			</div>
			</div>
		</article>

		<section id='scrolling-gallery' class='container-fluid'>
			<div class='container'>
			<div class='row'>
				<div class='col-xs-12 text-center'>
					sliding gallery
				</div>
			</div>
			</div>
		</section>

	</main>

<?php endwhile; ?>

<?php get_footer();?>

