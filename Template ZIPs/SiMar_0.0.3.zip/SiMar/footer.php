<section id='communities' class='container-fluid'>
	<div class='container'>
	<div class='row'>
		<div class='col-xs-12 h4 text-xs-center text-sm-left'>Primary Communities Served</div>
	</div>
	<div class='row'>
		<?php simar_get_community_list(); ?>
	</div>
	</div>
</section>

<footer class='container-fluid'>
	<div class='container'>
	<div class='row vertical-align-md text-center'>
		<div id='social-sharing' class='col-md-4 text-center'></div>
		<div id='company-info' class='col-md-4 text-center'>
			Copyright &copy <?php echo date('Y'); ?> <a target='_blank' href='http://thesimargroup.com'>The SiMar Group</a>
			<?php wp_nav_menu( array('theme_location' => 'Footer Menu')); ?>
		</div>
		<div id='social-links' class='col-md-4 text-center'><?php simar_get_social_media(); ?></div>
	</div>
	</div>
</footer>

</div> <!-- wrapper -->

	<?php wp_footer(); ?>
</body>
</html>