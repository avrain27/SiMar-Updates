<section id='sidebar' class='col-xs-10 col-xs-offset-1 col-md-4 col-md-offset-0 text-xs-center'>
	
	<div class="embed-responsive embed-responsive-16by9">
			<iframe class="embed-responsive-item" src="//www.youtube.com/embed/7kiMjJ01X6Q?rel=0"></iframe>
	</div>

	<div class='well'>
		<span class='h3'>Here is an announcement!</span>
		<span class='glyphicon glyphicon-bullhorn'></span>
	</div>
</section>