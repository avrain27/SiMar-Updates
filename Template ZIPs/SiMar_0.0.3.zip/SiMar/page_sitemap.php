<?php
/**
 * Template Name: Site Map
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>
<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-12 col-md-8 col-xs-justify'>
				<?php the_content(); ?>
				<?php
				/* Page Info -- MASS INPUT */
				$pages = get_all_page_ids(); # gets all PAGE ids (excludes index)
				$id = get_the_ID(); # Gets page ID
				for($i=0; $i<count($pages); $i++){
					echo "<a href='?p=".$pages[$i]."'>".get_the_title($pages[$i])."</a><br><br>";
				}
				?>
			</section>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>
<?php endwhile; ?>

<?php get_footer(); ?>