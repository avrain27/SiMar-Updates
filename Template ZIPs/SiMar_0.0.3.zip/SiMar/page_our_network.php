<?php
/**
 * Template Name: Our Network
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>
<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-12 col-md-8 col-xs-justify'>
				<?php the_content(); ?>
				Below is a list of businesses that represent a support network of the products and/or services we offer.  Many of these businesses are local to our community and take pride in promoting to support local businesses.  We invite you to consider the businesses below for other services or products you may be in need of to help support the local communities.  Thanks for considering the businesses in Our Network.
				<br><br>
				<?php echo do_shortcode( "[TSMG_CRM name='our_network']" ); ?>
			</section>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>
<?php endwhile; ?>

<?php get_footer(); ?>