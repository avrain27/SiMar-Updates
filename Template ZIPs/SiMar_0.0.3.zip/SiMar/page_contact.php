<?php
/**
 * Template Name: Contact Page
 *
 * @package WordPress
 * @subpackage SiMar
 * @since SiMar 0.0.1
 */
 ?>

 <?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>
<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='contact-form' class='col-xs-12 col-md-8 col-xs-justify'>
				<?php the_content(); ?>
				<div class='row'>
					<div id='form' class='col-xs-10 col-xs-offset-1 col-md-6 text-xs-center text-md-justify'>
					</div>

					<div id='contact_info' class='col-xs-10 col-xs-offset-1 col-md-6 text-xs-center text-md-justify'>
					</div>
				</div>
			</section>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>
<?php endwhile; ?>

<?php get_footer(); ?>