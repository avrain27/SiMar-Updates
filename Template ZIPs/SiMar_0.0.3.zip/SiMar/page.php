<?php get_header(); ?>

<?php while( have_posts() ) : the_post(); ?>
<main role='main'>

	<article id='content' class='container-fluid'>
		<div class='container'>
		<div class='row'>
			<section id='text-content' class='col-xs-12 col-md-8 col-xs-justify'>
			<?php the_content(); ?>
			</section>
			
			<?php get_sidebar(); ?>
		</div>
		</div>
	</article>

</main>
<?php endwhile; ?>

<?php get_footer(); ?>