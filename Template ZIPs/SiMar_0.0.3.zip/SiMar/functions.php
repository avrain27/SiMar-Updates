<?php
show_admin_bar(false);

function register_bootstrap()
{
    // jQuery
    wp_deregister_script('jquery');
    wp_register_script('jquery', includes_url('/js/jquery/jquery.js'), false, null, true);  
 	wp_enqueue_script('jquery');  
 	// visual fix for page loads
    wp_enqueue_script( 'simar-load', get_template_directory_uri() . '/includes/simar_load_page.js', array(), true, true);
    //bootstrap 
    wp_enqueue_style( 'bootstrapstyle', get_template_directory_uri() . '/bootstrap/css/bootstrap.min.css' );
    wp_enqueue_script( 'bootstrap-script', get_template_directory_uri() . '/bootstrap/js/bootstrap.min.js', array('jquery'), true, true);
}
add_action('wp_enqueue_scripts', 'register_bootstrap');

function SiMar_Scripts() 
{
	wp_enqueue_style( 'style', get_stylesheet_uri() );
	register_nav_menu('Main Menu', 'Main Menu used in the main site navigation.');
	register_nav_menu('Footer Menu', 'Footer Menu used in the footer (Generally: Site Map, Our Network, Youtube).');
}
SiMar_Scripts();

include(get_template_directory().'/includes/simar_hex2rgba.php');
include(get_template_directory().'/includes/simar_social_media.php');
include(get_template_directory().'/includes/simar_update_theme.php');

?>