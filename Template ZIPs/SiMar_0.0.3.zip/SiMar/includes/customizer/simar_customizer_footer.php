<?php
/* ==== Parent: simar_customizer.php ==== */
/* = Settings and Controls for: Footer == */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_google', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_google', array(
	'label'			=> __( 'Google Plus Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_facebook', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_facebook', array(
	'label'			=> __( 'Facebook Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_twitter', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_twitter', array(
	'label'			=> __( 'Twitter Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('social_media_instagram', array(
	'sanitize_callback' => 'esc_url_raw'
));
$wp_customize->add_control( 'social_media_instagram', array(
	'label'			=> __( 'Instagram Link' ),
	'section' 		=> 'footer_settings'
));
/////////////////////////////////////////////////////////
?>