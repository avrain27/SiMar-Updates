<?php
/* ===== Parent: simar_customizer.php ===== */
/* = Settings and Controls for: Community = */

/////////////////////////////////////////////////////////
$wp_customize->add_setting('community_bg_color', array(
	'default' 			=> '#fff',
	'sanitize_callback' => 'sanitize_hex_color'
));
$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'community_bg_color', array(
	'label' 	=> 'Communities BG Color',
	'section' 	=> 'community_settings'
)));
/////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
$wp_customize->add_setting('community_list', array(
	'sanitize_callback' => 'esc_textarea'
));
$wp_customize->add_control( 'community_list', array(
	'label'			=> __( 'Communities List' ),
	'type' 			=> 'textarea',
	'section' 		=> 'community_settings',
	'description' 	=> 'Paste the alphabetized, comma-separated list. EX: DeWitt, Ann Arbor OR DeWitt,Ann Arbor'
));
/////////////////////////////////////////////////////////
?>