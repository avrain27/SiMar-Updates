<?php 
# WA FRONTED SUPPORT
function my_editor_options($exisiting_options){
	//It is recommended to do an array_merge with the exisiting options to not break other settings
	return array_merge($exisiting_options, array(
		"defaults" => array(
			"permission"   => "default",
			"toolbar"      => "full",
			"media_upload" => true
		),
		"post_types" => array(
			"page" => array(
				"editable_areas" => array(
					array(
						"container"  => "section#text-content",
						"field_type" => "post_content",
						"auto_configure" => true,
						"toolbar"    => "full"
					)
				)
			)
		)
	)); 
}
add_filter('wa_fronted_options', 'my_editor_options');
?>