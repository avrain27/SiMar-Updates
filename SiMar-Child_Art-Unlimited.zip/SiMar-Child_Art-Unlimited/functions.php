<?php
/*Image Slider Size*/
add_image_size( 'homepage-rotator', '1150', '300', true );
function simar_enqueue_styles() {

    $parent_style = 'parent-style';

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );
}
add_action( 'wp_enqueue_scripts', 'simar_enqueue_styles' );

// cuztomizer api 
require_once( get_template_directory() . '/includes/simar_customizer.php'); // may need _uri once live
add_action( 'customize_register', 'simar_customize_register' );
/**
 * Used by hook: 'customize_preview_init'
 * 
 * @see add_action('customize_preview_init',$func)
 */
function simar_customizer_live_preview()
{
	wp_enqueue_script( 
		  'simar-themecustomizer',			//Give the script an ID
		  get_template_directory_uri().'/includes/customizer/simar-customizer.js',//Point to file
		  array( 'jquery','customize-preview' ),	//Define dependencies
		  '1.02',						//Define a version (optional) 
		  true						//Put script in footer?
	);
}
add_action( 'customize_preview_init', 'simar_customizer_live_preview' );

include(get_template_directory() . '/includes/simar_custom_css.php');
add_action('wp_head', 'simar_custom_css');

// MENU REGISTER
register_nav_menu('Glass Fusing', 'Menu to be used for subpages of Glass Fusing.');
?>